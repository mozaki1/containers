﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace IDisposableExample
{
    class Program
    {
        static void Main(string[] args)
        {
            MyResources myResource = new MyResources("somepath");
            myResource.Dispose();
        }
    }

    class MyResources : IDisposable
    {
        //The managed resource handle
        TextReader tr = null;

        public MyResources(string path)
        {
            //Lets emulate the managed resource aquisition
            Console.WriteLine("Aquiring Managed Resources");
            tr = new StreamReader(path);

            //Lets emulate the unmabaged resource aquisition
            Console.WriteLine("Aquiring Unmanaged Resources");

        }

        void ReleaseManagedResources()
        {
            Console.WriteLine("Releasing Managed Resources");
            if (tr != null)
            {
                tr.Dispose();
            }
        }

        void ReleaseUnmangedResources()
        {
            Console.WriteLine("Releasing Unmanaged Resources");
        }

        public void ShowData()
        {
            //Emulate class usage
            if (tr != null)
            {
                Console.WriteLine(tr.ReadToEnd() + " /some unmanaged data ");
            }
        }

        public void Dispose()
        {
            Console.WriteLine("Dispose called from outside");
            // If this function is being called the user wants to release the
            // resources. lets call the Dispose which will do this for us.
            Dispose(true);

            // Now since we have done the cleanup already there is nothing left
            // for the Finalizer to do. So lets tell the GC not to call it later.
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            Console.WriteLine("Actual Dispose called with a " + disposing.ToString());
            if (disposing == true)
            {
                //someone want the deterministic release of all resources
                //Let us release all the managed resources
                ReleaseManagedResources();
            }
            else
            {
                // Do nothing, no one asked a dispose, the object went out of
                // scope and finalized is called so lets next round of GC 
                // release these resources
            }

            // Release the unmanaged resource in any case as they will not be 
            // released by GC
            ReleaseUnmangedResources();

        }

        ~MyResources()
        {
            Console.WriteLine("Finalizer called");
            // The object went out of scope and finalized is called
            // Lets call dispose in to release unmanaged resources 
            // the managed resources will anyways be released when GC 
            // runs the next time.
            Dispose(false);
        }
    }

}

﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Security;
using System.Security.Permissions;
using System.Security.Policy;
using System.Reflection;
using System.IO;

//http://msdn.microsoft.com/en-us/library/ms229913(v=vs.90).aspx
//This example will not work - code prvoded just to see the syntax for test purposes.  CAS was obsoleteed and a number of box tweaks have to be made to run this sample.
//it basically copies the test.exe into another directory and tries ot execute it but will fail because no FILEIOpermission has been granted
[assembly: FileIOPermission(SecurityAction.RequestMinimum, Unrestricted = true)]
namespace SimpleSandboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create the permission set to grant to other assemblies. 
            // In this case we are granting the permissions found in the LocalIntranet zone.
            PermissionSet pset = GetNamedPermissionSet("LocalIntranet");
            if (pset == null)
                return;
            AppDomainSetup ads = new AppDomainSetup();
            // Identify the folder to use for the sandbox.
            Directory.CreateDirectory("C:\\Sandbox");
            ads.ApplicationBase = "C:\\Sandbox";
            //change these paths to fit yopur dev env
            // Copy the application to be executed to the sandbox.
            //tEST - OptionalPerms
            //File.Copy(@"C:\development\70-483\70-483\CASBasicsTest\bin\Debug\Test.exe", "C:\\sandbox\\Test.exe", true);
            //File.Copy(@"C:\development\70-483\70-483\CASBasicsTest\bin\Debug\Test.pdb", "C:\\sandbox\\Test.pdb", true);
            //RequestRefuseExample - specifically refuse it
            File.Copy(@"C:\development\70-483\70-483\RequestRefuseExample\bin\Debug\RequestRefuseExample.exe", "C:\\sandbox\\RequestRefuseExample.exe", true);
            File.Copy(@"C:\development\70-483\70-483\RequestRefuseExample\bin\Debug\RequestRefuseExample.pdb", "C:\\sandbox\\RequestRefuseExample.pdb", true);

            Evidence hostEvidence = new Evidence();

            // Create the sandboxed domain.
            AppDomain sandbox = AppDomain.CreateDomain(
                "Sandboxed Domain",
                hostEvidence,
                ads,
                pset,
                GetStrongName(Assembly.GetExecutingAssembly()));
            sandbox.ExecuteAssemblyByName("Test");

            //should get:
            //Additional information: Could not load file or assembly 'Test, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null' or one of its dependencies. Failed to grant minimum permission requests. (Exception from HRESULT: 0x80131417)

            
        }

        public static StrongName GetStrongName(Assembly assembly)
        {
            if (assembly == null)
                throw new ArgumentNullException("assembly");

            AssemblyName assemblyName = assembly.GetName();
            Debug.Assert(assemblyName != null, "Could not get assembly name");

            // Get the public key blob. 
            byte[] publicKey = assemblyName.GetPublicKey();
            if (publicKey == null || publicKey.Length == 0)
                throw new InvalidOperationException("Assembly is not strongly named");

            StrongNamePublicKeyBlob keyBlob = new StrongNamePublicKeyBlob(publicKey);

            // Return the strong name. 
            return new StrongName(keyBlob, assemblyName.Name, assemblyName.Version);
        }
        private static PermissionSet GetNamedPermissionSet(string name)
        {
            IEnumerator policyEnumerator = SecurityManager.PolicyHierarchy();

            // Move through the policy levels to the machine policy level. 
            while (policyEnumerator.MoveNext())
            {
                PolicyLevel currentLevel = (PolicyLevel)policyEnumerator.Current;

                if (currentLevel.Label == "Machine")
                {
                    NamedPermissionSet copy = currentLevel.GetNamedPermissionSet(name);
                    return (PermissionSet)copy;
                }
            }
            return null;
        }

    }
}

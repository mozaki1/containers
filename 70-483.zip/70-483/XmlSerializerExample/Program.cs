﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace XmlSerializerExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a new instance of the test class
            TestClass TestObj = new TestClass();

            // Set some dummy values
            TestObj.SomeString = "foo";

            TestObj.Settings.Add("A");
            TestObj.Settings.Add("B");
            TestObj.Settings.Add("C");
                 
            // Create a new XmlSerializer instance with the type of the test class
            XmlSerializer SerializerObj = new XmlSerializer(typeof(TestClass));

            // Create a new file stream to write the serialized object to a file
            TextWriter WriteFileStream = new StreamWriter(@"test.xml");
            SerializerObj.Serialize(WriteFileStream, TestObj);

            // Cleanup
            string text = string.Empty;
            WriteFileStream.Close();
            using(TextReader ReadFileStream = new StreamReader(@"test.xml"))
           
                text = ReadFileStream.ReadToEnd();
            // using(TextReader ReadFileStream = new StreamReader(@"test.xml"))
            //{
              
            //    TestClass testClassOut = (TestClass)SerializerObj.Deserialize(ReadFileStream);
            //    Console.WriteLine("TestClass SomeString: {0}", testClassOut.SomeString);
            //    Console.ReadLine();
            //}
            using(TextReader reader = new StringReader(text))
            {
                var result = (TestClass)SerializerObj.Deserialize(reader);
            }

            using(TextReader ReadFileStream = new StreamReader(text))
            {
                text = ReadFileStream.ReadToEnd();
                TestClass testClassOut = (TestClass)SerializerObj.Deserialize(ReadFileStream);
                Console.WriteLine("TestClass SomeString: {0}", testClassOut.SomeString);
                Console.ReadLine();
            }
        }
    }
}


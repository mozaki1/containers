﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlSerializerExample
{
    // This is the test class we want to 
    // serialize:
    public class TestClass
    {
        private string someString;
        public string SomeString
        {
            get { return someString; }
            set { someString = value; }
        }
        //wont serialize, its private
        private List<string> settings = new List<string>();
     
        public List<string> Settings
        {
            get { return settings; }
            set { settings = value; }
        }

        // These will be ignored
        [NonSerialized()]
        private int willBeIgnored1 = 1;
        private int willBeIgnored2 = 1;

    }

}

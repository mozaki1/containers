﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Text;
using System.Threading.Tasks;

namespace ConcurrentQueueExample
{
    class CQ_EnqueueDequeuePeek
    {
        // Demonstrates: 
        // ConcurrentQueue<T>.Enqueue() 
        // ConcurrentQueue<T>.TryPeek() 
        // ConcurrentQueue<T>.TryDequeue() 
        static void Main()
        {
            // Construct a ConcurrentQueue.
            ConcurrentQueue<int> cq = new ConcurrentQueue<int>();

            // Populate the queue. 
            for (int i = 0; i < 10000; i++)
                cq.Enqueue(i);

            // Peek at the first element. 
            int result;
            if (!cq.TryPeek(out result))
            {
                Console.WriteLine("CQ: TryPeek failed when it should have succeeded");
            }
            else if (result != 0)
            {
                Console.WriteLine("CQ: Expected TryPeek result of 0, got {0}", result);
            }
            else
            {
                Console.WriteLine("CQ: 0 AS IT SHOULD BE");
            }

            int outerSum = 0;
            // An action to consume the ConcurrentQueue.
            Action action = () =>
            {       
                int localSum = 0;
                int localValue;
                while (cq.TryDequeue(out localValue))
                {
                    Console.WriteLine("oN THREAD {0}, WORKING ON {1}", Thread.CurrentThread.ManagedThreadId, localValue);
                    localSum += localValue;
                }
                
                //OUTERSUM = OUTERSUM + LOCALSUM
                Interlocked.Add(ref outerSum, localSum);
            };

            // Start 4 concurrent consuming actions.
            Parallel.Invoke(action, action, action, action);

            Console.WriteLine("outerSum = {0}, should be 49995000", outerSum);
            Console.ReadLine();
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ParallelLoopingBasicExample
{
    class Program
    {
        

        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            System.Threading.Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                   BasicForLoop();
                    break;
                case "2":
                    BasicForEach();
                    break;
                case "3":
                    ParallelThreadLocalForExample();
                    break;
                case "4":
                    ParallelThreadLocalForEachExample();
                    break;
                case "5":
                    ParallelCancelExample();
                    break;
                case "6":
                    ParallelException();
                    break;
                case "7":
                    ParallelPartitionerExample();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void ParallelPartitionerExample()
        {
            // Source must be array or IList. 
            var source = Enumerable.Range(0, 100000).ToArray();

            // Partition the entire source array. -- only use this if you are doing allot of iterations but not much work in each iteration
            var rangePartitioner = Partitioner.Create(0, source.Length);

            double[] results = new double[source.Length];

            // Loop over the partitions in parallel.
            Parallel.ForEach(rangePartitioner, (range, loopState) =>
            {
                // Loop over each range element without a delegate invocation. 
                for (int i = range.Item1; i < range.Item2; i++)
                {
                    results[i] = source[i] * Math.PI;
                }
            });

            Console.WriteLine("Operation complete. Print results? y/n");
            char input = Console.ReadKey().KeyChar;
            if (input == 'y' || input == 'Y')
            {
                foreach (double d in results)
                {
                    Console.Write("{0} ", d);
                }
            }
            RunExample();
        }

        private static void ParallelException()
        {
            // Create some random data to process in parallel. 
            // There is a good probability this data will cause some exceptions to be thrown. 
            byte[] data = new byte[5000];
            Random r = new Random();
            r.NextBytes(data);

            try
            {
                ProcessDataInParallel(data);
            }

            catch (AggregateException ae)
            {
                
                // This is where you can choose which exceptions to handle. 
                foreach (var ex in ae.InnerExceptions)
                {
                    if (ex is ArgumentException)                     
                      Console.WriteLine(ex.Message);                     
                    else
                        throw ex;
                }
            }

            Console.WriteLine("Press any key to exit.");
            RunExample();
        }

        private static void ProcessDataInParallel(byte[] data)
        {
            // Use ConcurrentQueue to enable safe enqueueing from multiple threads. 
            var exceptions = new ConcurrentQueue<Exception>();

            // Execute the complete loop and capture all exceptions.
            Parallel.ForEach(data, d =>
            {
                try
                {
                    // Cause a few exceptions, but not too many. 
                    if (d < 0x3)
                        throw new ArgumentException(String.Format("value is {0:x}. Elements must be greater than 0x3.", d));
                    else
                        Console.Write(d + " ");
                }
                // Store the exception and continue with the loop.                     
                catch (Exception e) { exceptions.Enqueue(e); }
            });

            // Throw the exceptions here after the loop completes. 
            if (exceptions.Count > 0) throw new AggregateException(exceptions);
        }

        private static void ParallelCancelExample()
        {
            int[] nums = Enumerable.Range(0, 10000000).ToArray();
            CancellationTokenSource cts = new CancellationTokenSource();

           // Use ParallelOptions instance to store the CancellationToken
            ParallelOptions po = new ParallelOptions();
            
            po.CancellationToken = cts.Token;
            po.MaxDegreeOfParallelism = System.Environment.ProcessorCount;
            Console.WriteLine("My systems processor count s the same as the degrees of parallelism I will allow which is {0}", po.MaxDegreeOfParallelism);
            Console.WriteLine("Press any key to start. Press 'c' to cancel.");
            Console.ReadKey();

            // Run a task so that we can cancel from another thread.
            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("The cancel thread is ruunning on threadID {0}", Thread.CurrentThread.ManagedThreadId);
                if (Console.ReadKey().KeyChar == 'c')
                    cts.Cancel();
                Console.WriteLine("press any key to exit");
            });

            try
            {
                //Another thread running
                Console.WriteLine("The parallel thread is ruunning on threadID {0}", Thread.CurrentThread.ManagedThreadId);
                Parallel.ForEach(nums, po, (num) =>
                {
                    double d = Math.Sqrt(num);
                    Thread.Sleep(10);
                    Console.WriteLine("{0} on {1}", d, Thread.CurrentThread.ManagedThreadId);
                    po.CancellationToken.ThrowIfCancellationRequested();
                });
            }
            catch (OperationCanceledException e)
            {
                Console.WriteLine(e.Message);
            }

            RunExample();
        }

       

        private static void ParallelThreadLocalForEachExample()
        {
            int[] nums = Enumerable.Range(0, 1000000).ToArray();
            long total = 0;

            //Parameter 1: source that will be iterated
            //Parameter 2: type of variable that will store thread local state (long) here, initialized to 0, corresponds to last parater in the third parameter (subtotal)
            //Parameter 3: loop index, loopstate, retrun value - matches type of third parameter
            //Parameter 4: "local finally" interlocked is the last thing that runs and corresponds to the thread local return type specified in the 3rd param
           
            Parallel.ForEach<int, long>(nums, () => 0, (j, loop, subtotal) => 
            {
                                            subtotal += j; //modify local variable 
                                            return subtotal; // value to be passed to next iteration - the thread local variable
            },
                // Method to be executed when all loops have completed. 
                // finalResult is the final value of subtotal. supplied by the ForEach method.
                                        (finalResult) => Interlocked.Add(ref total, finalResult)
                                        );

            Console.WriteLine("The total from Parallel.ForEach is {0}", total);
            RunExample();
        }

        private static void ParallelThreadLocalForExample()
        {
            int[] nums = Enumerable.Range(0, 1000000).ToArray();
            long total = 0;

            // Use type parameter to make subtotal a long, not an int
            //Parameter 1: start of iteration
            //Parameter 2: end of iteration
            //Parameter 3: type of variable that will store thread local state (long) here, initialized to 0
            //Parameter 4: loop index, loopstate, retrun value - matches type of third parameter
            //Parameter 5: "local finally" interlocked is the last thing that runs and corresponds to the thread local return type specified in the 3rd param

            Parallel.For<long>(0, nums.Length, () => 0, (j, loop, subtotal) =>
            {
                subtotal += nums[j];
                return subtotal;
            },               
                (x) => Interlocked.Add(ref total, x)
            );

            Console.WriteLine("The total is {0}", total);
            RunExample();

        }

        private static void BasicForEach()
        {
            // A simple source for demonstration purposes. Modify this path as necessary. 
            string[] files = System.IO.Directory.GetFiles(@"C:\Users\Public\Pictures\Sample Pictures", "*.jpg");
            string newDir = @"C:\Users\Public\Pictures\Sample Pictures\Modified";
            System.IO.Directory.CreateDirectory(newDir);

            //  Method signature: Parallel.ForEach(IEnumerable<TSource> source, Action<TSource> body)
            ParallelLoopResult plr = Parallel.ForEach(files, currentFile =>
            {
                // The more computational work you do here, the greater  
                // the speedup compared to a sequential foreach loop. 
                string filename = System.IO.Path.GetFileName(currentFile);
                System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(currentFile);

                bitmap.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                bitmap.Save(System.IO.Path.Combine(newDir, filename));

                // Peek behind the scenes to see how work is parallelized. 
                // But be aware: Thread contention for the Console slows down parallel loops!!!
                Console.WriteLine("Processing {0} on thread {1}", filename,
                                    Thread.CurrentThread.ManagedThreadId);

            } //close lambda expression
            ); //close method invocation 

            Console.WriteLine("parallel loop complete {0}", plr.IsCompleted);
            RunExample();
        }

        private static void BasicForLoop()
        {

            List<int> collectionOfNumbers = Enumerable.Range(1, 500).ToList();

            var stopWatch = new System.Diagnostics.Stopwatch();

            stopWatch.Start();

            // Sequential version             
            foreach (var item in collectionOfNumbers)
            {
                Process(item);
            }

            stopWatch.Stop();

            Console.WriteLine("a normal loop time {0}", stopWatch.ElapsedMilliseconds);
            stopWatch.Reset();

            stopWatch.Start();
            // Parallel equivalent
            Parallel.ForEach(collectionOfNumbers, item => Process(item));
            stopWatch.Stop();
            Console.WriteLine("ParallelLoop time {0}", stopWatch.ElapsedMilliseconds);
            RunExample();
        }

        private static void Process(int item)
        {
            Thread.Sleep(50);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingBasicExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Thread Start/Stop/Join Sample");

            Alpha oAlpha = new Alpha();

            // Create the thread object, passing in the Alpha.Beta method
            // via a ThreadStart delegate. This does not start the thread.
            Thread oThread = new Thread(oAlpha.Beta);

            // Start the thread
            Console.WriteLine("Starting Alpha.beta thread");
            oThread.Start();

            // Spin for a while waiting for the started thread to become
            // alive:
            Console.WriteLine("Waiting for Alpha.beta to become alive");
            while (!oThread.IsAlive) ;

            // Put the Main thread to sleep for 1 millisecond to allow oThread
            // to do some work:
            Console.WriteLine("Alpha.beta Working");
            Thread.Sleep(1);

            // Request that oThread be stopped
            Console.WriteLine("Kill Alpha.beta");
            oThread.Abort();

            // Wait until oThread finishes. Join also has overloads
            // that take a millisecond interval or a TimeSpan object.
            Console.WriteLine("Back to main thread when Alpha.beta dies");
            oThread.Join();
           
            Console.WriteLine("Alpha.Beta has finished");

            try
            {
                Console.WriteLine("Try to restart the Alpha.Beta thread, should fail");
                oThread.Start();
            }
            catch (ThreadStateException)
            {
                Console.Write("ThreadStateException trying to restart Alpha.Beta. ");
                Console.WriteLine("Expected since aborted threads cannot be restarted.");
            }
            Console.ReadLine();
        }

    }
}


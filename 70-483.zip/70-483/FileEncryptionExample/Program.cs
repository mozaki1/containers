﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileEncryptionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            const string dataToEncrypt = "Hey encrypt me";

            string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "MyEncrypted.txt");

            File.WriteAllText(filePath, dataToEncrypt);
            File.Encrypt(filePath);
        }
    }
}

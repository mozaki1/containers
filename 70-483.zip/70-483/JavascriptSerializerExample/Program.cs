﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.IO;

namespace JavascriptSerializerExample
{
    class Program
    {
        static void Main(string[] args)
        {

            Company company = GetData();
            string json = string.Empty;
            // Pass "company" object for conversion object to JSON string
           //  json = new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(company);

            // Write that JSON to txt file
            File.WriteAllText(Environment.CurrentDirectory + @"\JSON.txt", json);

            json = File.ReadAllText(Environment.CurrentDirectory + @"\JSON.txt");

           // company = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Company>(json);


        }
        public static Company GetData()
        {
            return new Company()
            {
                Title = "Company Ltd",
                Employees = new List<Employee>()
            {
                new Employee(){ Name = "Mark CEO", EmployeeType = EmployeeType.CEO },
                new Employee(){ Name = "Matija Božičević", EmployeeType = EmployeeType.Developer },
                new Employee(){ Name = "Steve Developer", EmployeeType = EmployeeType.Developer}
            }
            };
        }

    }
    /// <summary>
    /// Company info
    /// </summary>
    public class Company
    {
        public string Title { get; set; }
        public List<Employee> Employees { get; set; }
    }

    /// <summary>
    /// Employee info
    /// </summary>
    public class Employee
    {
        public string Name { get; set; }
        public EmployeeType EmployeeType { get; set; }
    }

    /// <summary>
    /// Types of employees
    /// (just to se how JSON deals with enums!)
    /// </summary>
    public enum EmployeeType
    {
        CEO,
        Developer
    }

}

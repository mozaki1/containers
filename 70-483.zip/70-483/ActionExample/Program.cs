﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActionExample
{
    
    class Program
    {
        static void MyAction(Func<int,int> func)
        {

        }
        static void Main(string[] args)
        {
            MyAction((x) =>
                {
                    return x;
            
                }
            );
            // Example Action instances.
            // ... First example uses one parameter.
            // ... Second example uses two parameters.
            // ... Third example uses no parameter.
            // ... None have results.
            Action<int> example1 =  (int x) => Console.WriteLine("Write {0}", x);
            Action<int, int> example2 = (x, y) => Console.WriteLine("Write {0} and {1}", x, y);
            Action example3 = () => Console.WriteLine("Done");

            // Call the anonymous methods.
            example1.Invoke(1);
            example2.Invoke(2, 3);
            example3.Invoke();

            Console.WriteLine("A dictionary of Actions");
            Dictionary<string, Action> dict = new Dictionary<string, Action>();
            dict["cat"] = new Action(Cat); //No parameters
            dict["dog"] = new Action(Dog);
            dict["squirrel"] = new Action(Squirrel);

            dict["cat"].Invoke();
            dict["dog"].Invoke();
            dict["squirrel"].Invoke();
            Console.ReadLine();
        }

        static void Cat()
        {
            Console.WriteLine("CAT");
        }

        static void Dog()
        {
            Console.WriteLine("DOG");
        }

        static void Squirrel()
        {
            Console.WriteLine("Ima squirrel");
        }

    }
}

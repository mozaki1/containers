﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Text;
using System.Web;

namespace StriNgWriterExample
{
    class Program
    {
        static void Main()
        {
            // Example string data
            string[] arr = new string[]
	        {
	            "One",
	            "Two",
	            "Three"
	        };
                    // Write markup and strings to StringWriter
            StringWriter stringWriter = new StringWriter();
            using (System.Web.UI.HtmlTextWriter writer = new System.Web.UI.HtmlTextWriter(stringWriter))
            {
                foreach (string item in arr)
                {
                    writer.RenderBeginTag(System.Web.UI.HtmlTextWriterTag.Div);
                    // Send internal StringBuilder to markup method.
                    WriteMarkup(item, stringWriter.GetStringBuilder());
                    writer.RenderEndTag();
                }
            }
            Console.WriteLine(stringWriter.ToString());
            Console.ReadLine();
        }

        /// <summary>
        /// Writes to StringBuilder parameter
        /// </summary>
        static void WriteMarkup(string sourceString, StringBuilder builder)
        {
            builder.Append("Some").Append(" text");
        }
    }

}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Globalization;
namespace StringsGeneralExample
{
    class Program
    {     

        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    StringsDeclarationExample();
                    break;
                case "2":
                    StringsImmutabilityExample();
                    break;
                case "3":
                    StringsLiteralEmbedsExample();
                    break;
                case "4":
                    StringsFormatExample();
                    break;
                case "5":
                    StringsSubstringExample();
                    break;
                case "6":
                    StringsNullExample();
                    break;
                case "7":
                    StringsBuilderExample();
                    break;
                case "8":
                    StringsIndexOfExample();
                    break;
                case "9":
                    StringsDateCurrencyFormats();
                    break;
                case "10":
                    StringIterationExample();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void StringIterationExample()
        {
            var strings = new[] { "String 1", "String 2", "String 3" };

            // how can I iterate through the string array?

            #region Crazy

            Console.WriteLine(strings[0]);
            Console.WriteLine(strings[1]);
            Console.WriteLine(strings[2]);

            // not really iterating

            #endregion

            #region how abount an index variable?

            var index0 = 0;

            Console.WriteLine(strings[index0++]); // post increment
            Console.WriteLine(strings[index0++]); ;
            Console.WriteLine(strings[index0++]); ;

            // but wait - index is too big now
            // if we do
            Console.WriteLine(strings[index0++]); // we get an exception

            #endregion

            #region we could add a length check:
            var index1 = 0;

            if (index1 < strings.Length)
            {
                Console.WriteLine(strings[index1++]); ;
            }

            if (index1 < strings.Length)
            {
                Console.WriteLine(strings[index1++]); ;
            }

            if (index1 < strings.Length)
            {
                Console.WriteLine(strings[index1++]); ;
            }

            if (index1 < strings.Length)
            {
                // never runs!
                Console.WriteLine(strings[index1++]); ;
            }

            // but that is a lot of work!!!
            #endregion

            #region easier

            for (int i = 0; i < strings.Length; i++)
            {
                Console.WriteLine(strings[i]); ;
            }

            #endregion

            #region easy!

            foreach (var s in strings)
            {
                Console.WriteLine(s);
            }

            #endregion
        }

        private static void StringsDateCurrencyFormats()
        {
            double money = 323;
            CultureInfo provider = new CultureInfo("en-GB");
            Console.WriteLine("Short Date {0}", DateTime.Now.ToString("d"));
            Console.WriteLine("Long Date {0}", DateTime.Now.ToString("D"));
            Console.WriteLine("Month Date {0}",DateTime.Now.ToString("M"));
            Console.WriteLine("Money {0}", money.ToString("c", Thread.CurrentThread.CurrentUICulture));
            Console.WriteLine("bRITISH Money {0}", money.ToString("c", provider));
            RunExample();
        }

        private static void StringsIndexOfExample()
        {
            const string junk = "abcdefghijklmano";
            Console.WriteLine("Given {0}",junk);
            Console.WriteLine("Taking a value at substring of 3 and 5 should return defgh {0}", junk.Substring(3, 5));
            Console.WriteLine("Length of junk is 16: {0}", junk.Length);
            Console.WriteLine("index of a should be 0: {0}", junk.IndexOf("a"));
            Console.WriteLine("Lastindex of a should be 13: {0}", junk.LastIndexOf("a"));
            RunExample();
        }

        private static void StringsBuilderExample()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder("Rat: the ideal pet");
            Console.WriteLine("In string Replacement of a character in a stringBuilder Instance {0}",sb.ToString());

            sb[0] = 'C';
            System.Console.WriteLine(sb.ToString());


            System.Text.StringBuilder sb2 = new System.Text.StringBuilder();

            // Create a string composed of numbers 0 - 9 
            for (int i = 0; i < 10; i++)
            {
                sb2.Append(i.ToString());
            }
            System.Console.WriteLine(sb);  // displays 0123456789 

            // Copy one character of the string (not possible with a System.String)
            sb[0] = sb[9];
            Console.WriteLine("Copy one character of the string (not possible with a System.String)");

            System.Console.WriteLine(sb);  // displays 9123456789

            RunExample();
        }

        private static void StringsNullExample()
        {
            string str = "hello";
            string nullStr = null;
            string emptyStr = String.Empty;

            string tempStr = str + nullStr;
            // Output of the following line: hello
            Console.WriteLine("null string concatenated to an empty string is ok {0}", tempStr);

            bool b = (emptyStr == nullStr);
            // Output of the following line: False
            Console.WriteLine("An empty string and a null string are not equivalent via == {0}", b);

            bool c = emptyStr.Equals(nullStr);
            Console.WriteLine("An empty string and a null string are not equivalent via .Equals {0}", c);


            // The following line creates a new empty string. 
            string newStr = emptyStr + nullStr;

            // Null strings and empty strings behave differently. The following 
            // two lines display 0.
            Console.WriteLine("You can call methods on an empty string like the length {0}", emptyStr.Length);
            try
            {
                Console.WriteLine(nullStr.Length);
            }
            catch (Exception e)
            {
                Console.WriteLine("You CANNOT call methods on a Null string like the length, {0} ", e.Message);             
            }
               
            // The null character can be displayed and counted, like other chars. 
            string s1 = "\x0" + "abc";
            string s2 = "abc" + "\x0";
            // Output of the following line: * abc*
            Console.WriteLine("*" + s1 + "*");
            // Output of the following line: *abc *
            Console.WriteLine("*" + s2 + "*");
            // Output of the following line: 4
            Console.WriteLine(s2.Length);

            RunExample();
        }

        private static void StringsSubstringExample()
        {
            string s3 = "Visual C# Express";
           Console.WriteLine(s3.Substring(7, 2));    

            System.Console.WriteLine(s3.Replace("C#", "Basic"));
            // Output: "Visual Basic Express" 

            // Index values are zero-based 
            int index = s3.IndexOf("C");
            // index = 7

            string question = "hOW DOES mICROSOFT wORD DEAL WITH THE cAPS lOCK KEY?";
            Console.WriteLine(" in place replacements, fixing a capsLock issue {0}", question);
           
            System.Text.StringBuilder sb = new System.Text.StringBuilder(question);

            for (int j = 0; j < sb.Length; j++)
            {
                if (System.Char.IsLower(sb[j]) == true)
                    sb[j] = System.Char.ToUpper(sb[j]);
                else if (System.Char.IsUpper(sb[j]) == true)
                    sb[j] = System.Char.ToLower(sb[j]);
            }
            // Store the new string. 
            string corrected = sb.ToString();
            System.Console.WriteLine(corrected);
            RunExample();
        }

        private static void StringsFormatExample()
        {
            // Get user input.
            System.Console.WriteLine("Enter a number:");
            string input = System.Console.ReadLine();

            // Convert the input string to an int. 
            int j;
            bool success = System.Int32.TryParse(input, out j);

            if (success)
            {
                // Write a different string each iteration. 
                string s;
                for (int i = 0; i < 10; i++)
                {
                    // A simple format string with no alignment formatting.
                    s = System.String.Format("{0} times {1} = {2}", i, j, (i * j));
                    System.Console.WriteLine(s);
                }
            }
            else
            {
                Console.WriteLine("NaN");
            }
            RunExample();
        }

        private static void StringsLiteralEmbedsExample()
        {
            string columns = "Column 1\tColumn 2\tColumn 3";          
            Console.WriteLine("Embeded literals, columns: {0}", columns);

            string rows = "Row 1\r\nRow 2\r\nRow 3";
            Console.WriteLine("Embeded literals, rows: {0}", rows);

            string title = "\"The \u00C6olean Harp\", by Samuel Taylor Coleridge";
            Console.WriteLine("Embeded literals, Unicode: {0}", title);

            string quote = @"Her name was ""Sara.""";
            Console.WriteLine("Verbatim, quote: {0}", quote);
            RunExample();
        }

        private static void StringsImmutabilityExample()
        {
            string s1 = "A string is more ";
            string s2 = "than the sum of its chars.";

            // Concatenate s1 and s2. This actually creates a new 
            // string object and stores it in s1, releasing the 
            // reference to the original object hwich is now fgoing to be garbage collected
            s1 += s2;

            System.Console.WriteLine(s1);

            //create a reference to a string, and then "modify" the original string, the reference 
            //will continue to point to the original object instead of the new object that was created when the string was modified
            string s3 = "Hello ";
            string s4 = s3;
            s3 += "World";

            System.Console.WriteLine(s4);
            //Output: Hello
                       
            RunExample();

        }

        private static void StringsDeclarationExample()
        {
            // Declare without initializing. 
            string message1;

            // Initialize to null. 
            string message2 = null;

            // Initialize as an empty string. 
            // Use the Empty constant instead of the literal "".
            string message3 = System.String.Empty;

            //Initialize with a regular string literal. 
            string oldPath = "c:\\Program Files\\Microsoft Visual Studio 8.0";

            // Initialize with a verbatim string literal. 
            string newPath = @"c:\Program Files\Microsoft Visual Studio 9.0";

            // Use System.String if you prefer.
            System.String greeting = "Hello World!";

            // In local variables (i.e. within a method body) 
            // you can use implicit typing. 
            var temp = "I'm still a strongly-typed System.String!";

            // Use a const string to prevent 'message4' from 
            // being used to store another string value. 
            const string message4 = "You can't get rid of me!";

            // Use the String constructor only when creating 
            // a string from a char*, char[], or sbyte*. See 
            // System.String documentation for details. 
            char[] letters = { 'A', 'B', 'C' };
            string alphabet = new string(letters);

            Console.WriteLine("alphabet {0}", alphabet);          
            RunExample();
        }
    }
}

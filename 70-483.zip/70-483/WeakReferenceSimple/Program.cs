﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeakReferenceSimple
{
    class Program
    {
        /// <summary>
        /// Points to data that can be garbage collected any time.
        /// </summary>
        static WeakReference _weak;
        static void Main(string[] args)
        {

            Init();
            // See if weak reference is alive.
            object junk;
            if (_weak.IsAlive)
            {
                Console.WriteLine("Yep, alive and well");
                junk = _weak.Target;
            }
            junk = null;

            // Invoke GC.Collect.
            // ... If this is commented out, the next condition will evaluate true.

       
            GC.Collect(10);


            GC.WaitForFullGCComplete();
            GC.Collect();
            
           
            // Check alive.
            if (_weak.IsAlive)
            {
               // Console.WriteLine((_weak.Target as StringBuilder).ToString());
                Console.WriteLine("IsAlive");
            }
            else
            {
                Console.WriteLine("Nope, GC cleaned up the target object event htough _weak is still around");
            }

            // Finish.
            Console.WriteLine("[Done]");
            Console.Read();

        }
        private static void Init()
        {
            
            // Assign the WeakReference. target object
            _weak = new WeakReference(new StringBuilder("dsfsdfsdfsdf"));
        }
        
    }
}

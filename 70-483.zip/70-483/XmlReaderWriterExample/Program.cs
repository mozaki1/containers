﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Text;
using System.IO;

namespace XmlReaderWriterExample
{
    class Program
    {

        private static string data;
        private static Employee[] employees;
        static void Main()
        {
            Console.WriteLine("Create List of employee objects to work with");
            employees = GenerateEmployeesList();
                              
            Console.WriteLine("Write Employees XML By XmlWriter:");
            data = CreateEmployeesXmlWriterStyle(employees);                
            Console.WriteLine(data);

            Console.WriteLine("Read First Name by XmlReader:");
            //Feed it a stream of what you just created
            ReadXmlByXmlReader();
            
            
            //  By xmlDocument
            Console.WriteLine("Read ID by XMLDocument:");
            XmlDocument xml = new XmlDocument();
            ReadXmlByXmlDocument(xml);


            Console.WriteLine("Create by XDocument:");
            CreateEmployeesXDocumentStyle(employees);
            Console.WriteLine(data);

            Console.WriteLine("Read all Employees By Linq:");
            ReadWholeDocumentByXElement();
            ReadEmployeesByXlement();

            ReadEmployeesByXDocument();
            ReadWholeDocumentByXDocument();

            ReadEmployeeNamesByXElement();
            ReadEmployeeIDsByXAttribute();
            ReadAllSalariesByDescendants();

            //By XDocument, if XDocument.Load (data)

           
            Console.ReadLine();
        }

        private static void ReadXmlByXmlDocument(XmlDocument xml)
        {
            xml.LoadXml(data);

            XmlNodeList nodes = xml.GetElementsByTagName("Employee");
            if (nodes.Count > 0)
            {
                foreach (XmlNode node in nodes)
                {
                    Console.WriteLine(node.ChildNodes[3].InnerXml);
                }
            }
        }

        private static void ReadXmlByXmlReader()
        {
            using (XmlReader reader = XmlReader.Create(new StringReader(data)))
            {
                reader.MoveToContent();
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        // Get element name and switch on it.
                        switch (reader.Name)
                        {
                            case "FirstName":
                                Console.WriteLine(reader.ReadInnerXml());
                                break;
                        }
                    }
                }
            }
        }

        private static Employee[] GenerateEmployeesList()
        {
            Employee[] employees = new Employee[4];
            employees[0] = new Employee(1, "David", "Smith", 10000);
            employees[1] = new Employee(3, "Mark", "Drinkwater", 30000);
            employees[2] = new Employee(4, "Norah", "Miller", 20000);
            employees[3] = new Employee(12, "Cecil", "Walker", 120000);
            return employees;
        }

        public static string CreateEmployeesXmlWriterStyle(Employee[] employees)
        {
            StringWriter sw = new StringWriter();
            using (XmlWriter writer = XmlWriter.Create(sw, new XmlWriterSettings() { Indent = true }))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("Employees");
                writer.WriteAttributeString("Junk", "Test");

                foreach (Employee employee in employees)
                {
                    writer.WriteStartElement("Employee");
                    writer.WriteAttributeString("Junk", "to start element");
                    writer.WriteElementString("ID", employee.Id.ToString());
                    writer.WriteStartElement("FirstName");
                    writer.WriteAttributeString("internalAtt", "on sibling element");
                    writer.WriteValue(employee.FirstName);
                    writer.WriteEndElement();
                    // writer.WriteElementString("FirstName", employee.FirstName);
                    writer.WriteElementString("LastName", employee.LastName);
                    writer.WriteElementString("Salary", employee.Salary.ToString());

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndDocument();

                writer.Flush();
            }
            return sw.ToString();
        }
        #region Linq to XML
        public static void CreateEmployeesXDocumentStyle(Employee[] employees)
        {
            // xml declaration won't show up with tostring()
            XDocument xdoc = new XDocument(
                new XDeclaration("1.0", "UTF-16", null),  
                    new XElement("Employees", new XComment("Only 4 elements for demo purposes"), 
                        employees.Select(x => new XElement("Employee",
                            new XElement("ID", x.Id),
                            new XElement("FirstName", new XAttribute("myattr","a value"),x.FirstName),
                            new XElement("LastName", x.LastName),
                            new XElement("Salary", x.Salary)
                    ))));
            data = xdoc.ToString();

        }     
        public static void ReadWholeDocumentByXElement()
        {
             XElement xelement = XElement.Parse(data);
             Console.WriteLine("Read by XElement:");
            Console.WriteLine(xelement.ToString());
        }
        public static void ReadEmployeesByXlement()
        {
            XElement xelement = XElement.Parse(data);

            IEnumerable<XElement> employees = xelement.Elements();

            // Read the entire XML
            Console.WriteLine("Read by XElement:");
            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
            }
        }
        public static void ReadEmployeesByXDocument()
        {
            Console.WriteLine("Read by XDocument:");
            XDocument xdoc = XDocument.Parse(data);
            IEnumerable<XElement> employees = xdoc.Root.Elements();
            foreach (var employee in employees)
            {
                  Console.WriteLine(employee);
            }
        }

        private static void ReadEmployeeNamesByXElement()
        {
            XElement xelement = XElement.Parse(data);

            IEnumerable<XElement> employees = xelement.Elements();

            foreach (var employee in employees)
            {
                Console.WriteLine("Employee name: {0} {1}",employee.Element("FirstName").Value, employee.Element("LastName").Value);
            }
        }
        private static void ReadEmployeeIDsByXAttribute()
        {
            XElement xelement = XElement.Parse(data);

            IEnumerable<XElement> employees = xelement.Elements().Where(x => x.Element("FirstName").Attribute("myattr").Value == "a value");
            foreach (var employee in employees)
            {
                Console.WriteLine("Employee ID: {0}", employee.Element("ID").Value);
            }
        }
        private static void ReadAllSalariesByDescendants()
        {
            XElement xelement = XElement.Parse(data);
            IEnumerable<XElement> elements = xelement
                .Descendants("Salary")
                .OrderByDescending( x => (int)x);

            foreach (var salary in elements)
            {
                Console.WriteLine("Salaries: {0}",salary.Value);
            }
        }

        public static void ReadWholeDocumentByXDocument()
        {
            Console.WriteLine("Read by XDocument:");
            XDocument xdoc = XDocument.Parse(data);
            IEnumerable<XElement> employees = xdoc.Elements();
            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
            }
        }
        #endregion

        [DebuggerDisplay("Name={FirstName}")]
        public class Employee
        {
            int _id;
            string _firstName;
            string _lastName;
            int _salary;

           
            public Employee(int id, string firstName, string lastName, int salary)
            {
                this._id = id;
                this._firstName = firstName;
                this._lastName = lastName;
                this._salary = salary;
            }

            public int Id { get { return _id; } }
            public string FirstName { get { return _firstName; } }
            public string LastName { get { return _lastName; } }
            public int Salary { get { return _salary; } }
        }
    }
}

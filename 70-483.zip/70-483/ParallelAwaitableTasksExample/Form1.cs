﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;

namespace ParallelAwaitableTasksExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            resultsTextBox.Clear();
            await CreateMultipleTasksAsync();
            resultsTextBox.Text += "\r\n\r\nControl returned to startButton_Click.\r\n";

        }
         private async Task CreateMultipleTasksAsync()
        {
            // Declare an HttpClient object, and increase the buffer size. The 
            // default buffer size is 65,536.
            HttpClient client =  new HttpClient() { MaxResponseContentBufferSize = 1000000 };

            // Create and start the tasks. As each task finishes, DisplayResults  
            // displays its length.
            Task<int> download1 = ProcessURLAsync("http://msdn.microsoft.com", client);
            Task<int> download2 = ProcessURLAsync("http://msdn.microsoft.com/en-us/library/hh156528(VS.110).aspx", client);
            Task<int> download3 = ProcessURLAsync("http://msdn.microsoft.com/en-us/library/67w7t67f.aspx", client);
                          
            // Await each task. 
            //int length1 = await download1;
            //int length2 = await download2;
            //int length3 = await download3;
            //int total = length1 + length2 + length3;

             //Can also do it like this:
            Task<int>[] downloadTasks = { download1, download2, download3 };
            int[] lengths = await Task.WhenAll(downloadTasks);
            int total = lengths.Sum();

            // Display the total count for the downloaded websites.
            resultsTextBox.Text += string.Format("\r\n\r\nTotal bytes returned:  {0}\r\n", total);
        }


        async Task<int> ProcessURLAsync(string url, HttpClient client)
        {

            var byteArray = await client.GetByteArrayAsync(url);
            //can't do anything until there are results
            DisplayResults(url, byteArray);
            return byteArray.Length;
        }


        private void DisplayResults(string url, byte[] content)
        {
            // Display the length of each website. The string format  
            // is designed to be used with a monospaced font, such as 
            // Lucida Console or Global Monospace. 
            var bytes = content.Length;
            // Strip off the "http://".
            var displayURL = url.Replace("http://", "");
            resultsTextBox.Text += string.Format("\n\n{0,-58} {1,8}", displayURL, bytes);
        }
    }

}


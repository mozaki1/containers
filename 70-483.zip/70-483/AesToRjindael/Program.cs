﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace AesToRjindael
{
    
    class Program
    {
            public static string dataToEncrypt = @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()_+-=:;'}|]\{[.,<>/?";
            public static byte[] dataToProtectArray = Encoding.UTF8.GetBytes(dataToEncrypt);
            public static byte[] key16 = new byte[16];
            public static byte[] initializationVector16 = new byte[16];
            public static byte[] key32 = new byte[32];
            public static byte[] initializationVector32 = new byte[32];
            public static byte[] initializationVector64 = new byte[64];
            public static byte[] key64 = new byte[64];
            public static byte[] key128 = new byte[128];
            public static byte[] initializationVector128 = new byte[128];
            public static byte[] key256 = new byte[256];
            public static byte[] initializationVector256 = new byte[256];
            public static byte[] key512 = new byte[512];
            public static byte[] initializationVector512 = new byte[512];

            static void Main(string[] args)
            {

                //Get byte array of the data we will encrypt
                
                Random random = new Random();

                //use random 16 element key (16 bytes), larger key = more encrypted - should be secret
                random.NextBytes(key16);                
                random.NextBytes(initializationVector16);                
                random.NextBytes(key32);                
                random.NextBytes(initializationVector32);                
                random.NextBytes(key64);               
                random.NextBytes(initializationVector64);               
                random.NextBytes(key128);               
                random.NextBytes(initializationVector128);                
                random.NextBytes(key256);               
                random.NextBytes(initializationVector256);
                random.NextBytes(key512);
                random.NextBytes(initializationVector512);

               // AESDecryptRjindaelNoKeyIV();
                AESDecryptRjindael16KeyIV();
                AESDecryptRjindael32KeyIV();
                AESDecryptRjindael64KeyIV();
                AESDecryptRjindael128KeyIV();
                AESDecryptRjindael256KeyIV();
                AESDecryptRjindael512KeyIV();

                Console.ReadLine();

               
            }
        //We only care about being able to decrypt from rjindael.
            //private static void AESDecryptRjindaelNoKeyIV()
            //{               
            //    Console.WriteLine( "AES Decrypting Rijindael {0}:",System.Reflection.MethodBase.GetCurrentMethod().Name );
            //    Console.WriteLine("Encrypting");
            //    byte[] symEncryptedData = EncryptAway(GetEnryptor(), dataToProtectArray);
            //    Console.WriteLine("Decrypting");
            //    CompareResults(DecryptAway(GetDecryptor(), symEncryptedData));
                
            //}
            private static void AESDecryptRjindael16KeyIV()
            {
                Console.WriteLine("AES Decrypting Rijindael {0}:", System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine("Encrypting");
                byte[] symEncryptedData = EncryptAway(GetEnryptor(key16, initializationVector16), dataToProtectArray);
                Console.WriteLine("Decrypting");
                CompareResults(DecryptAway(GetDecryptor(key16, initializationVector16), symEncryptedData));
            }
            
            private static void AESDecryptRjindael32KeyIV()
            {
                Console.WriteLine("AES Decrypting Rijindael {0}:", System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine("Encrypting");
                byte[] symEncryptedData = EncryptAway(GetEnryptor(key32, initializationVector32), dataToProtectArray);
                Console.WriteLine("Decrypting");
                CompareResults(DecryptAway(GetDecryptor(key32, initializationVector32), symEncryptedData));
            }
           
            private static void AESDecryptRjindael64KeyIV()
            {
                Console.WriteLine("AES Decrypting Rijindael {0}:", System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine("Encrypting");
                byte[] symEncryptedData = EncryptAway(GetEnryptor(key64, initializationVector64), dataToProtectArray);
                Console.WriteLine("Decrypting");
                CompareResults(DecryptAway(GetDecryptor(key64, initializationVector64), symEncryptedData));
            }
           
            private static void AESDecryptRjindael128KeyIV()
            {
                Console.WriteLine("AES Decrypting Rijindael {0}:", System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine("Encrypting");
                byte[] symEncryptedData = EncryptAway(GetEnryptor(key128, initializationVector128), dataToProtectArray);
                Console.WriteLine("Decrypting");
                CompareResults(DecryptAway(GetDecryptor(key128, initializationVector128), symEncryptedData));
            }           
            private static void AESDecryptRjindael256KeyIV()
            {
                Console.WriteLine("AES Decrypting Rijindael {0}:", System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine("Encrypting");
                byte[] symEncryptedData = EncryptAway(GetEnryptor(key256, initializationVector256), dataToProtectArray);
                Console.WriteLine("Decrypting");
                CompareResults(DecryptAway(GetDecryptor(key256, initializationVector256), symEncryptedData));
            }
            private static void AESDecryptRjindael512KeyIV()
            {
                Console.WriteLine("AES Decrypting Rijindael {0}:", System.Reflection.MethodBase.GetCurrentMethod().Name);
                Console.WriteLine("Encrypting");
                byte[] symEncryptedData = EncryptAway(GetEnryptor(key512, initializationVector512), dataToProtectArray);
                Console.WriteLine("Decrypting");
                CompareResults(DecryptAway(GetDecryptor(key512, initializationVector512), symEncryptedData));
            }

            //public static ICryptoTransform GetEnryptor()
            //{
            //    return Program.GetEnryptor(null, null);
            //}
            //public static ICryptoTransform GetDecryptor()
            //{
            //    return Program.GetDecryptor(null, null);
            //}
            public static ICryptoTransform GetEnryptor(byte[] key, byte[] IV)
            {
                  var rjinDaelAlgorithm = new System.Security.Cryptography.RijndaelManaged();
                  if (key != null && IV != null)
                      return rjinDaelAlgorithm.CreateEncryptor(key, IV);
                  else 
                      return rjinDaelAlgorithm.CreateEncryptor();
            }
        
           private static ICryptoTransform GetDecryptor(byte[] key, byte[] IV)
            {
                var aesAlgorithm = new System.Security.Cryptography.AesCryptoServiceProvider();
                if (key != null && IV != null)
                    return aesAlgorithm.CreateDecryptor(key, IV);
                else
                    return aesAlgorithm.CreateDecryptor();
            }

           private static byte[] EncryptAway(ICryptoTransform encryptor, byte[] dataToEncrypt)
           {
              
               byte[] symEncryptedData;
               using (var memStream = new MemoryStream())
               using (var cryptoStream = new CryptoStream(memStream, encryptor, CryptoStreamMode.Write))
               {
                   cryptoStream.Write(dataToEncrypt, 0, dataToEncrypt.Length);
                   cryptoStream.FlushFinalBlock();
                   symEncryptedData = memStream.ToArray();
               }
               encryptor.Dispose();
               return symEncryptedData;
           }
           private static byte[] DecryptAway(ICryptoTransform decryptor, byte[] symEncryptedData)
           {
               
               byte[] symUnencyptedData;              
               using (var memStream = new MemoryStream())
               using (var cryptoStream = new CryptoStream(memStream, decryptor, CryptoStreamMode.Write))
               {
                   cryptoStream.Write(symEncryptedData, 0, symEncryptedData.Length);
                   cryptoStream.FlushFinalBlock();
                   symUnencyptedData = memStream.ToArray();
               }
               decryptor.Dispose();
               return symUnencyptedData;
           }
           private static void CompareResults(byte[] symUnencyptedData)
        {
            if (dataToProtectArray.SequenceEqual(symUnencyptedData))
                Console.WriteLine("They Match!");
            else
                Console.WriteLine("They Dont Match!");
        }
    }
}

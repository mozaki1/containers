﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsSimpleExample
{
    public class Counter
    {
        protected int threshold;
        protected int total;
        public event EventHandler ThresholdReached;

        public Counter(int passedThreshold)
        {
            threshold = passedThreshold;
        }

        public virtual void Add(int x)
        {
            total += x;
            if (total >= threshold)
            {
                OnThresholdReached(ConstructArgs());
            }
        }
        protected virtual EventArgs ConstructArgs()
        {
            return EventArgs.Empty;
        }
        protected virtual void OnThresholdReached(EventArgs e)
        {
            EventHandler handler = ThresholdReached;
            if (handler != null)
            {
                handler(this, e);
            }
        }

       
    }

   
}

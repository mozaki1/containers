﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsSimpleExample
{
    public delegate void CustomHandlerDelagate(object sender, CustomThresholdEventArgs e);
    
}

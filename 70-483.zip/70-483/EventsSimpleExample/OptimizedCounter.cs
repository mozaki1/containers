﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsSimpleExample
{
    public class OptimizedCounter : Counter
    {
         public OptimizedCounter(int passedThreshold): base (passedThreshold){}

         public event EventHandler<CustomThresholdEventArgs> DefaultDelegateThresholdReached;

         protected override void OnThresholdReached(EventArgs e)
         {
             EventHandler<CustomThresholdEventArgs> handler = DefaultDelegateThresholdReached;
             CustomThresholdEventArgs customArgs = (CustomThresholdEventArgs)e;
            if (handler != null)
            {
                handler(this, customArgs);
            }
         }
         protected override EventArgs ConstructArgs()
         {
             CustomThresholdEventArgs args = new CustomThresholdEventArgs();
             args.Threshold = threshold;
             args.TimeReached = DateTime.Now;
             return args;
         }
        public override void Add(int x)
        {
            total += x;
            if (total >= threshold)
            {
                OnThresholdReached(ConstructArgs());
            }

        }

    }
}

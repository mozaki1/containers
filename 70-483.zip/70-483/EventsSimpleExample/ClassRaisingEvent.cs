﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsSimpleExample
{
    public class ClassRaisingEvent
    {
        public int ThresholdCounter { get; set; }
        public event CustomHandlerDelagate ThresholdChanged;

        protected void OnThresholdChanged(CustomThresholdEventArgs eventArgs)
        {
            CustomHandlerDelagate handler = ThresholdChanged;

            if (handler != null)
                handler(this, eventArgs);
        }

        public void AddToThreshold(int i)
        {
            ThresholdCounter += i;
            if(ThresholdCounter > 10)
            {
                CustomThresholdEventArgs args = new CustomThresholdEventArgs() { Threshold = ThresholdCounter, TimeReached = DateTime.Now };
 
                OnThresholdChanged(args);
            }

        }
    }
}

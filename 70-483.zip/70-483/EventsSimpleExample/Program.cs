﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace EventsSimpleExample
{
    class Program
    {
        public static void Main(string[] args)
        {

            RunExample();
        }

        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    EventWithCustomArgsAndDelagate();
                    break;
                case "2":
                    EventWithDefaulHandler();
                    break;
                case "3":
                    EventWithCustomArgs();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void EventWithCustomArgs()
        {
            OptimizedCounter c = new OptimizedCounter(new Random().Next(10));
            c.DefaultDelegateThresholdReached += c_ThresholdReached;

            Console.WriteLine("press 'a' key to increase total");
            while (Console.ReadKey(true).KeyChar == 'a')
            {
                Console.WriteLine("adding one via optimized counter");
                c.Add(1);
            }
            RunExample();
        }

        private static void EventWithDefaulHandler()
        {
            Counter c = new Counter(new Random().Next(10));
            c.ThresholdReached += c_ThresholdReached;

            Console.WriteLine("press 'a' key to increase total");
            while (Console.ReadKey(true).KeyChar == 'a')
            {
                Console.WriteLine("adding one");
                c.Add(1);
            }
            
            RunExample();
        }

        static void c_ThresholdReached(object sender, EventArgs e)
        {
            Console.WriteLine(string.Format("The threshold was reached.  The sender was {0}",sender.ToString()));           
        }

        
        
        private static void EventWithCustomArgsAndDelagate()
        {
            ClassRaisingEvent c = new ClassRaisingEvent();
            c.ThresholdChanged += HandleThresholdReached;
           for (int i = 0; i < 25; i++)
			{
                Console.WriteLine(string.Format("Adding to Threshold: {0}", i));
                c.AddToThreshold(i);
			}
             RunExample();
        
        }
        public static void HandleThresholdReached(object sender, CustomThresholdEventArgs args)
        {
            Console.WriteLine(string.Format("Received a notification that the threshold was reached by {0} at {1}", args.Threshold, args.TimeReached  ));
        }
    }
}

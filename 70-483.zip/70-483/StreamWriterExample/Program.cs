﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace StreamReadWrite
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Get the directories currently on the C drive.
            DirectoryInfo[] cDirs = new DirectoryInfo(@"c:\").GetDirectories();

            // Write each directory name to a file. 
            //using (StreamWriter sw = new StreamWriter("CDriveDirs.pdf"))
            //{
                using(FileStream
           fileStream = new FileStream("CDriveDirs.pdf", FileMode.Create))
                {

                    var hello = "Big Mo runs the Show";
                var array =  Convert.FromBase64String( hello);

                
                 await fileStream.WriteAsync(array,0,array.Length);
                var size=array.Length;

               
            }

            // Read and show each line from the file. 
            string line = "";
            using (StreamReader sr = new StreamReader("CDriveDirs.txt"))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
            Console.ReadLine();
        }
    }
}
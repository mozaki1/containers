﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskCancellationExample
{
    class Program
    {
        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    ExecuteTaskBasic();
                    break;

                case "2":
                    ExecuteTaskCancellationChained();
                    break;
            
               
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void ExecuteTaskBasic()
        {
            var tokenSource2 = new CancellationTokenSource();
            CancellationToken ct = tokenSource2.Token;

            var task = Task.Factory.StartNew(() =>
            {

                // Were we already canceled?
                ct.ThrowIfCancellationRequested();

                bool moreToDo = true;
                while (moreToDo)
                {
                    Console.WriteLine("Doing work!!");
                    // Poll on this property if you have to do 
                    // other cleanup before throwing. 
                    if (ct.IsCancellationRequested)
                    {
                        Console.WriteLine("Responding tot he cancel token");
                        // Clean up here, then...
                        ct.ThrowIfCancellationRequested();
                    }

                }
            }, tokenSource2.Token); // Pass same token to StartNew.

            Thread.Sleep(2000);
             Console.WriteLine("Cancelling the task!!");
            tokenSource2.Cancel();

            // Just continue on this thread, or Wait/WaitAll with try-catch: 
            try
            {
                task.Wait();
            }
            catch (AggregateException e)
            {
                foreach (var v in e.InnerExceptions)
                    Console.WriteLine(e.Message + " " + v.Message);
            }

            RunExample();
        }


        private static void ExecuteTaskCancellationChained()
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            Task task = new Task(() =>
            {
                CancellationToken ct = cts.Token;
                for (int i = 0; i < 500; i++)
                {
                    Console.WriteLine("Task1 is processing");
                    if (ct.IsCancellationRequested)
                        Console.WriteLine("task1 is being cancelled");
                    ct.ThrowIfCancellationRequested();
                    // Do the work. 
                    //...                 
                }
               
            },
                cts.Token
                );

            Task task2 = task.ContinueWith((antecedent) =>
            {
                CancellationToken ct = cts.Token;

                while (true)
                {
                    Console.WriteLine("Task2 is processing");
                    if(ct.IsCancellationRequested)
                        Console.WriteLine("task2 is being cancelled");
                    ct.ThrowIfCancellationRequested();
                    // Do the work. 
                    //...                        
                }
            },
                cts.Token);

            task.Start();
            //put this here to delay so that we can see that the second task will be cancelled if that is the task you are in when the cancel happens

            Thread.SpinWait(1111000000);

            // Antecedent and/or continuation will  
            // respond to this request, depending on when it is made.
            cts.Cancel();
            RunExample();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsMulticastExample
{
    class Program
    {
        //Simple multicast delagate
        private delegate void StringHandlerDelegate(string s);

        static void Main()
        {
            // Add two methods to delegate instance
            StringHandlerDelegate del = Method1;
            del += Method2;
            del += Method3;

            // Invoke
            foreach (StringHandlerDelegate nextDel in del.GetInvocationList())
            {
                try
                {
                    if (nextDel.Method.Name.Equals("Method3",StringComparison.InvariantCultureIgnoreCase))
                    {
                        Console.WriteLine(string.Format("Skipping {0}", nextDel.Method.Name));
                    }
                    else
                    {
                    Console.WriteLine(string.Format("Firing off {0} from multcast", nextDel.Method.Name));
                    nextDel.Invoke("From multicast!!!!!");
                    }
                }
                catch (Exception xx)
                {
                    Console.WriteLine(string.Format("Exception in {0}: {1}", nextDel.Method.Name, xx.Message));
                }
            }
            Console.ReadLine();
        }

        static void Method1(string text)
        {
            Console.WriteLine("Method1, {0}", text);
            throw new Exception("Problem in Method1");
        }

        static void Method2(string name)
        {
            Console.WriteLine("Method2, {0}", name);
        }

        static void Method3(string name)
        {
            //Never called because we filter it out before invocation
            Console.WriteLine("Method2, {0}", name);
        }

    }
}

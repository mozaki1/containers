﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskContinuationExample
{
    class Program
    {
        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    ExecuteBasicContinuedTask();
                    break;
                case "2":
                    ExecuteBasicMultiTaskContinuation();
                    break;
                case "3":
                    ExecuteBasicMultiTaskContinuationWithState();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void ExecuteBasicMultiTaskContinuationWithState()
        {
            // Start a root task that performs work.
            Task<DateTime> t = Task<DateTime>.Run(delegate { return DoWork(); });

            // Create a chain of continuation tasks, where each task is  
            // followed by another task that performs work.
            List<Task<DateTime>> continuations = new List<Task<DateTime>>();
            for (int i = 0; i < 5; i++)
            {
                // Provide the current time as the state of the continuation.
                t = t.ContinueWith(delegate { return DoWork(); }, DateTime.Now);
                continuations.Add(t);
            }

            // Wait for the last task in the chain to complete.
            t.Wait();

            // Print the creation time of each continuation (the state object) 
            // and the completion time (the result of that task) to the console. 
            foreach (var continuation in continuations)
            {
                DateTime start = (DateTime)continuation.AsyncState;
                DateTime end = continuation.Result;

                Console.WriteLine("Task was created at {0} and finished at {1}.",
                   start.TimeOfDay, end.TimeOfDay);
            }
            RunExample();
        }
        // Simluates a lengthy operation and returns the time at which 
        // the operation completed. 
        public static DateTime DoWork()
        {
            // Simulate work by suspending the current thread  
            // for two seconds.
            Thread.Sleep(2000);

            // Return the current time. 
            return DateTime.Now;
        }

        private static void ExecuteBasicMultiTaskContinuation()
        {
            Task<int>[] tasks = new Task<int>[2];
            tasks[0] = new Task<int>(() =>
            {
                Random rnd = new Random();
                // Do some work...  
                return rnd.Next();
            });

            tasks[1] = new Task<int>(() =>
            {
                // Do some work... 
                Random rnd = new Random();
                // Do some work...  
                return rnd.Next();
            });

            //Continue wehn all tasks are done, then do the sum action
            var continuationTask = Task.Factory.ContinueWhenAll(
                            tasks,
                            (antecedents) =>
                            {
                                int answer = antecedents[0].Result + antecedents[1].Result;
                                Console.WriteLine("The answer is {0}", answer);
                            });

            tasks[0].Start();
            tasks[1].Start();
            continuationTask.Wait();

            RunExample();

        }        
        private static void ExecuteBasicContinuedTask()
        {
            // The antecedent task. Can also be created with Task.Factory.StartNew.
            Task<DayOfWeek> taskA = new Task<DayOfWeek>(() => DateTime.Today.DayOfWeek);

            // The continuation. Its delegate takes the antecedent task 
            // as an argument and can return a different type.
            Task<string> continuation = taskA.ContinueWith((antecedent) =>
            {
                return String.Format("Today is {0}.", antecedent.Result);
            }
          );

            // Start the antecedent.
            taskA.Start();

            // Use the contuation's result.
            Console.WriteLine(continuation.Result);
            RunExample();
        }
    }
}

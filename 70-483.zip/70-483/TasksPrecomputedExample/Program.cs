﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

// Demonstrates how to use Task<TResult>.FromResult to create a task  
// that holds a pre-computed result. 
class CachedDownloads
{
    // Holds the results of download operations. 
    static ConcurrentDictionary<string, string> cachedDownloads = new ConcurrentDictionary<string, string>();

    // Asynchronously downloads the requested resource as a string. 
    public static Task<string> DownloadStringAsync(string address)
    {
        // First try to retrieve the content from cache. 
        string content;
        if (cachedDownloads.TryGetValue(address, out content))
        {
            Console.WriteLine("Getting from cache for {0}", address);
            return Task.FromResult<string>(content);
        }

        // If the result was not in the cache, download the  
        // string and add it to the cache. 
        return Task.Run(async () =>
        {
            Console.WriteLine("await started on {0}", address);
            content = await new WebClient().DownloadStringTaskAsync(address);
            Console.WriteLine("await over on {0}", address);
            cachedDownloads.TryAdd(address, content);
            return content;
        });
    }

    // Synchronously downloads the requested resource as a string. 
    public static Task<string> DownloadStringSynch(string address)
    {

        string content;
        // If the result was not in the cache, download the  
        // string and add it to the cache. 
        return Task.Run( () =>
        {
            Console.WriteLine("synchroinously started on {0}", address);
            content = new WebClient().DownloadString(address);
            Console.WriteLine("synchroinously over on {0}", address);
            cachedDownloads.TryAdd(address, content);
            return content;
        });
    }


    static void Main(string[] args)
    {
        // The URLs to download. 
        string[] urls = new string[]
      {
         "http://msdn.microsoft.com",
         "http://www.contoso.com",
         "http://www.microsoft.com"
      };

        // Used to time download operations.
        Stopwatch stopwatch = new Stopwatch();

        // Compute the time required to download the URLs.
        stopwatch.Start();
        var downloads = from url in urls
                        select DownloadStringAsync(url);
       
        Task.WhenAll(downloads).ContinueWith(results =>
        {
            Console.WriteLine("After waitall");
            stopwatch.Stop();

            // Print the number of characters download and the elapsed time.
            Console.WriteLine("Asynchronously - Retrieved {0} characters. Elapsed time was {1} ms.",
               results.Result.Sum(result => result.Length),
               stopwatch.ElapsedMilliseconds);
        })
        .Wait();

        // Perform the same operation a second time. The time required 
        // should be shorter because the results are held in the cache.
        stopwatch.Restart();
        downloads = from url in urls
                    select DownloadStringAsync(url);
        Task.WhenAll(downloads).ContinueWith(results =>
        {
            stopwatch.Stop();

            // Print the number of characters download and the elapsed time.
            Console.WriteLine("Cached - Retrieved {0} characters. Elapsed time was {1} ms.",
               results.Result.Sum(result => result.Length),
               stopwatch.ElapsedMilliseconds);
        })
        .Wait();


        // Perform the same operation a third time. This time required 
        // should be longer because the results are retrieved synchronously.
        stopwatch.Restart();
        downloads = from url in urls
                    select DownloadStringSynch(url);
           
        Task.WhenAll(downloads).ContinueWith(results =>
        {
            Console.WriteLine("After waitall");
            stopwatch.Stop();

            // Print the number of characters download and the elapsed time.
            Console.WriteLine("Synchronously  - Retrieved {0} characters. Elapsed time was {1} ms.",
               results.Result.Sum(result => result.Length),
               stopwatch.ElapsedMilliseconds);
        })
        .Wait();

        Console.ReadLine();
    }
}

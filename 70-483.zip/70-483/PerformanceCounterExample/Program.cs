﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
namespace PerformanceCounterExample
{
    class Program
    {

        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            System.Threading.Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    SimplePerfCounter();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void SimplePerfCounter()
        {
            try
            {

                if (PerformanceCounterCategory.Exists("MCSD_Example"))
                    PerformanceCounterCategory.Delete("MCSD_Example");
                
            //Check if the category Exists first, can't add to an existing one
                if (!PerformanceCounterCategory.Exists("MCSD_Example"))
                {
                    CounterCreationDataCollection counterCreationDataCollection = new CounterCreationDataCollection();
                    CounterCreationData counterCreationData = new CounterCreationData()
                    {
                        CounterName = "MSCD counter Name",
                        CounterHelp = "Just an Example",
                        CounterType = PerformanceCounterType.NumberOfItems32

                    };

                    counterCreationDataCollection.Add(counterCreationData);

                    PerformanceCounterCategory.Create("MCSD_Example", "This is just an example at category Level", PerformanceCounterCategoryType.SingleInstance, counterCreationDataCollection);
                }
                PerformanceCounter myCounter = new PerformanceCounter("MCSD_Example", "MSCD counter Name", false);
                GeneratePerformaceData(myCounter);
                RunExample();
            }
            catch (Exception ex)
            {

                Console.WriteLine("sECURITY eXCEPTION: RUN ME AS AN ADMIN", ex);
                Console.ReadLine();
            }
                
        }

        private static void GeneratePerformaceData(PerformanceCounter counter)
        {
            Random rnd = new Random(100);
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(1000);
                counter.RawValue = rnd.Next(1000);
            }
        }
        
    }
}

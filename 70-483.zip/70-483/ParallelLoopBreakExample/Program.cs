﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Test
{
    static void Main()
    {
        StopLoop();
        BreakAtThreshold();

        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();
    }

    private static void StopLoop()
    {
        Console.WriteLine("Stop loop...");
        double[] source = MakeDemoSource(1000, 1);
        ConcurrentStack<double> results = new ConcurrentStack<double>();

        // i is the iteration variable. loopState is a  
        // compiler-generated ParallelLoopState
        Parallel.For(0, source.Length, (j, loopState) =>
        {
            Console.WriteLine("working on {0}", j);
            // Take the first 100 values that are retrieved 
            // from anywhere in the source. 
            if (j < 251)
            {
                Console.WriteLine("Computing on {0}", j);
                // Accessing shared object on each iteration 
                // is not efficient. See remarks. 
                double d = Compute(source[j]);
                results.Push(d);
            }
            else
            {
                Console.WriteLine("stopping on {0}", j);
                //tELLS PARALLEL TO JUST STOP, it may not finish the work that has begun on other threads (results will be less then 250)
                loopState.Stop();
                //tells parallel to go finish up other threads but don't continue iterating (results will be 250)
                //loopState.Break();
                return;
            }

        } // Close lambda expression.
        ); // Close Parallel.For

        Console.WriteLine("Results contains {0} elements", results.Count());
      
    }


    static void BreakAtThreshold()
    {
        double[] source = MakeDemoSource(10000, 1.0002);
        ConcurrentStack<double> results = new ConcurrentStack<double>();

        // Store all values below a specified threshold.
        Parallel.For(0, source.Length, (i, loopState) =>
        {
            double d = Compute(source[i]);
            results.Push(d);
            if (d > .2)
            {
                // Might be called more than once!, tells parallel to go finish up other threads but don't continue iterating
                loopState.Break();
                Console.WriteLine("Break called at iteration {0}. d = {1} ", i, d);
                Thread.Sleep(1000);
            }
        });

        Console.WriteLine("results contains {0} elements", results.Count());
    }

    static double Compute(double d)
    {
        //Make the processor work just a little bit. 
        return Math.Sqrt(d);
    }


    // Create a contrived array of monotonically increasing 
    // values for demonstration purposes.  
    static double[] MakeDemoSource(int size, double valToFind)
    {
        double[] result = new double[size];
        double initialval = .01;
        for (int i = 0; i < size; i++)
        {
            initialval *= valToFind;
            result[i] = initialval;
        }

        return result;
    }
}

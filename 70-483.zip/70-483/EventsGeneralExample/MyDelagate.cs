﻿using System;
namespace EventsGeneralExample
{
    public delegate void ChangedEventHandler(object sender, EventArgs e);

}

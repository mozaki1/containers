﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsGeneralExample
{
   
      public  class EventListener
        {
            private ListWithChangedEvent List;

            public EventListener(ListWithChangedEvent list)
            {
                List = list;
                // Add "ListChanged" to the Changed event on "List".
                List.Changed += new ChangedEventHandler(ListChanged);
                List.Changed += new ChangedEventHandler(ListChangedToo);
            }

            // This will be called whenever the list changes. because we are adding it to the subscription handler
            private void ListChanged(object sender, EventArgs e)
            {
                Console.WriteLine("This is called when the event fires.");
            }
            // This will be called too 
            private void ListChangedToo(object sender, EventArgs e)
            {
                Console.WriteLine("Im also called becuase it's a multicast");
            }

            public void Detach()
            {
                // Detach the event and delete the list
                List.Changed -= new ChangedEventHandler(ListChanged);
                List.Changed -= new ChangedEventHandler(ListChangedToo);
                List = null;
            }
        }    
}

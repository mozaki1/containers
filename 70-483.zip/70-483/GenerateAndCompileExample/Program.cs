﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.IO;
using Microsoft.CSharp;

namespace GenerateAndCompileExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a code compile unit root
            CodeCompileUnit ccu = new CodeCompileUnit();

            //Create a namespace
            CodeNamespace cn = new CodeNamespace("TestingThisCrap");
            CodeCommentStatement cc = new CodeCommentStatement(new CodeComment("This is a test, I should be at the namespace level above decalration"));
            //Add it to the code compile unit
            ccu.Namespaces.Add(cn);
            cn.Comments.Add(cc);

            //Import a namespace
            cn.Imports.Add(new CodeNamespaceImport("System"));

            //Create a class declaration
            CodeTypeDeclaration cd = new CodeTypeDeclaration("MyClass");
            cd.Comments.Add(new CodeCommentStatement(new CodeComment("Right above the class declaration")));

            //Add it to your namespace
            cn.Types.Add(cd);

            //Create a starting entry point
            CodeEntryPointMethod start = new CodeEntryPointMethod();
            CodeCommentStatement cs = new CodeCommentStatement(new CodeComment("This is a test, I should be above the start method"));
            start.Comments.Add(cs);

            //Create a variable reference to console
            CodeTypeReferenceExpression csSystemConsoleType = new CodeTypeReferenceExpression("System.Console");
           
            // Build a Console.WriteLine statement.
            CodeMethodInvokeExpression cs1 = new CodeMethodInvokeExpression(csSystemConsoleType, "WriteLine", new CodePrimitiveExpression("This is a test of a compile unit"));
            
            //Add to entry point method
            start.Statements.Add(cs1);
  
            // Build a Console.WriteLine statement.
            CodeMethodInvokeExpression cs2 = new CodeMethodInvokeExpression(csSystemConsoleType, "WriteLine", new CodePrimitiveExpression("Another test"));
            start.Statements.Add(cs2);
            
            // Build a Console.WriteLine statement.
            CodeMethodInvokeExpression cs3 = new CodeMethodInvokeExpression(csSystemConsoleType, "ReadLine");
            start.Statements.Add(cs3);

            //Add back to class declaration
            cd.Members.Add(start);

            CompileCSharpCode(GenerateCSharpCode(ccu),"MyExe");
            Console.ReadLine();
        }
        public static string GenerateCSharpCode(CodeCompileUnit compileunit)
        {
            // Generate the code with the C# code provider.
            CSharpCodeProvider provider = new CSharpCodeProvider();

            // Build the output file name. 
            string sourceFile;
            if (provider.FileExtension[0] == '.')
            {
                sourceFile = "HelloWorld" + provider.FileExtension;
            }
            else
            {
                sourceFile = "HelloWorld." + provider.FileExtension;
            }

            // Create a TextWriter to a StreamWriter to the output file. 
            using (StreamWriter sw = new StreamWriter(sourceFile, false))
            {
                IndentedTextWriter tw = new IndentedTextWriter(sw, "    ");

                // Generate source code using the code provider.
                provider.GenerateCodeFromCompileUnit(compileunit, tw,
                    new CodeGeneratorOptions());

                // Close the output file.
                tw.Flush();
                tw.Close();
            }
            string dat;
            using(StreamReader sr = new StreamReader(sourceFile))
            {
                dat = sr.ReadToEnd();
            }
            Console.WriteLine(dat);
            
            return sourceFile;
        }

        public static bool CompileCSharpCode(string sourceFile, string exeFile)
        {
            CSharpCodeProvider provider = new CSharpCodeProvider();

            // Build the parameters for source compilation.
            CompilerParameters cp = new CompilerParameters();

            // Add an assembly reference.
            cp.ReferencedAssemblies.Add("System.dll");

            // Generate an executable instead of 
            // a class library.
            cp.GenerateExecutable = true;

            // Set the assembly file name to generate.
            cp.OutputAssembly = exeFile;

            // Save the assembly as a physical file.
            cp.GenerateInMemory = false;

            // Invoke compilation.
            CompilerResults cr = provider.CompileAssemblyFromFile(cp, sourceFile);

            if (cr.Errors.Count > 0)
            {
                // Display compilation errors.
                Console.WriteLine("Errors building {0} into {1}",
                    sourceFile, cr.PathToAssembly);
                foreach (CompilerError ce in cr.Errors)
                {
                    Console.WriteLine("  {0}", ce.ToString());
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Source {0} built into {1} successfully.",
                    sourceFile, cr.PathToAssembly);
            }

            // Return the results of compilation. 
            if (cr.Errors.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

    }
}

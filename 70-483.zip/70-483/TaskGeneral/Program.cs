﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskGeneral
{
    class Program
    {
        static void Main(string[] args)
        {
            RunExample();
        }

        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    RunStatementsConcurrentlyViaInvoke();
                    break;
                case "2":
                    ExecuteBasicTaskWithStart();
                    break;
                case "3":
                    ExecuteBasicTaskWithRun();
                    break;
                case "4":                    
                    ExecuteBasicTaskWithTaskFactory();
                    break;
                case "5":
                    ExecuteTaskListWithTaskFactoryNamedDelegate();
                    break;
                case "6":
                    ExecuteTaskListWithTaskFactoryLamdaBad();
                    break;
                case "7":
                    ExecuteTaskListWithTaskFactoryLamdaWithState();
                    break;
                case "8":
                    ExecuteTaskListWithTaskFactoryLamdaWithAsyncState();
                    break;
                case "9":
                    ExecuteTaskListWithTaskFactoryAndContinue();
                    break;
                default:
                    Environment.Exit(0);
                    break;

            }
        }

        private static void ExecuteTaskListWithTaskFactoryAndContinue()
        {
            //An array of random numbers
            var getData = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("First Task is building an array");
                Random rnd = new Random();
                int[] values = new int[100];
                for (int ctr = 0; ctr <= values.GetUpperBound(0); ctr++)
                    values[ctr] = rnd.Next();

                return values;
            });
            //Once thats done, now we can work with that array
            var processData = getData.ContinueWith((x) =>
            {
              
                int n = x.Result.Length;
                long sum = 0;
                double mean;
                Console.WriteLine("Continuing the second Task is calculating from the array {0}", n);
                for (int ctr = 0; ctr <= x.Result.GetUpperBound(0); ctr++)
                    sum += x.Result[ctr];

                mean = sum / (double)n;
                return Tuple.Create(n, sum, mean);
            });
            var displayData = processData.ContinueWith((x) =>
            {
                Console.WriteLine("Third task is printing out tuple calculated in second task");
                return String.Format("N={0:N0}, Total = {1:N0}, Mean = {2:N2}",
                                     x.Result.Item1, x.Result.Item2,
                                     x.Result.Item3);
            });
            Console.WriteLine(displayData.Result);
            RunExample(); 
        }

        private static void ExecuteTaskListWithTaskFactoryLamdaWithAsyncState()
        {
            Task[] taskArray = new Task[10];
            for (int i = 0; i < taskArray.Length; i++)
            {
                taskArray[i] = Task.Factory.StartNew((Object obj) => 
                    {
                        CustomData data = obj as CustomData;
                        if (data==null)                    
		                    return;

                        data.ThreadNum = Thread.CurrentThread.ManagedThreadId;	                    
                    },
                    new CustomData(){Name=i, CreationTime = DateTime.Now.Ticks});                
            }

            Task.WaitAll(taskArray);
            foreach (var task in taskArray)
            {
                var data = task.AsyncState as CustomData;
                if (data != null)
                {
                    Console.WriteLine("Task #{0} created at {1} on thread #{2}.", data.Name, data.CreationTime, data.ThreadNum);
                }
            }

            RunExample(); 
        }

        private static void ExecuteTaskListWithTaskFactoryLamdaBad()
        {

            Task[] taskArray = new Task[10];
            Console.WriteLine("This is bad because lamda lambda doesn't capture the variable as expected. It only captures the final value, not the value as it mutates after each iteration, notice the identcal identifier");
            for (int i = 0; i < taskArray.Length; i++)
            {
                //Not doing anything with state obj
                taskArray[i] = Task.Factory.StartNew((Object obj) =>
                {
                    var data = new CustomData() { Name = i, CreationTime = DateTime.Now.Ticks };
                    data.ThreadNum = Thread.CurrentThread.ManagedThreadId;
                    Console.WriteLine("Task #{0} created at {1} on thread #{2}.",data.Name, data.CreationTime, data.ThreadNum);
                },
                i);
            }
            //Wait for all tasks befoe proceeding
            Task.WaitAll(taskArray);     

            RunExample(); 
        }
        private static void ExecuteTaskListWithTaskFactoryLamdaWithState()
        {

            Task[] taskArray = new Task[10];
            for (int i = 0; i < taskArray.Length; i++)
            {
                taskArray[i] = Task.Factory.StartNew((Object obj) =>
                {
                    Console.WriteLine("Now we grab state from previous iteration, using the state obj");
                    CustomData data = obj as CustomData;
                    if (data == null)
                        return;
                    //Give it the current threadID
                    data.ThreadNum = Thread.CurrentThread.ManagedThreadId;
                    Console.WriteLine("Task #{0} created at {1} on thread #{2}.", data.Name, data.CreationTime, data.ThreadNum);
                },
                //Here's the state object to use on this iteration
                new CustomData() { Name = i, CreationTime = DateTime.Now.Ticks }, TaskCreationOptions.PreferFairness);
            }
            Task.WaitAll(taskArray);    

            RunExample();
        }

        private static void ExecuteTaskListWithTaskFactoryNamedDelegate()
        {
            Task<Double>[] taskArray = { Task<Double>.Factory.StartNew(() => DoComputation(1.0)),
                                     Task<Double>.Factory.StartNew(() => DoComputation(100.0)), 
                                     Task<Double>.Factory.StartNew(() => DoComputation(1000.0)) };

            var results = new Double[taskArray.Length];
            Double sum = 0;

            for (int i = 0; i < taskArray.Length; i++)
            {
                //When accessing Result, if the chosen task isn't done it blocks until it is
                results[i] = taskArray[i].Result;
                Console.Write("{0:N1} {1}", results[i], (i == taskArray.Length - 1) ? "= " : "+ ");
                sum += results[i];
            }
            Console.WriteLine("{0:N1}", sum);


            RunExample(); 
        }

        private static Double DoComputation(Double start)
        {
            Double sum = 0;
            for (var value = start; value <= start + 10; value += .1)
                sum += value;

            return sum;
        }


        private static void ExecuteBasicTaskWithTaskFactory()
        {
            if (Thread.CurrentThread.Name != "Main")
                Thread.CurrentThread.Name = "Main";

            // Better: Create and start the task in one operation. 
            Task taskA = Task.Factory.StartNew(() => Console.WriteLine("Hello from taskA."));

            // Output a message from the calling thread.
            Console.WriteLine("Hello from thread '{0}'.", Thread.CurrentThread.Name);

            taskA.Wait();          
            RunExample(); 

        }

        private static void ExecuteBasicTaskWithRun()
        {
            if (Thread.CurrentThread.Name != "Main")
                Thread.CurrentThread.Name = "Main";

            // Define and run the task.
            Task taskA = Task.Run(() => Console.WriteLine("Hello from taskA."));

            // Output a message from the calling thread.
            Console.WriteLine("TaskA was created and started all at once '{0}'.", Thread.CurrentThread.Name);
            taskA.Wait();

            RunExample();
        }

        private static void ExecuteBasicTaskWithStart()
        {
            if (Thread.CurrentThread.Name != "Main")
                Thread.CurrentThread.Name = "Main";

            // Create a task and supply a user delegate by using a lambda expression. 
            Task taskA = new Task(() => Console.WriteLine("I'm in taskA and my ID is {0}", Thread.CurrentThread.ManagedThreadId));
           
            // Start the task.
            taskA.Start();

            // Output a message from the calling thread.
            Console.WriteLine("Hello from thread '{0}', myID is '{1}' .", Thread.CurrentThread.Name, Thread.CurrentThread.ManagedThreadId);
            taskA.Wait();
            RunExample();

        }
        private static void RunStatementsConcurrentlyViaInvoke()
        {
            //No ordering these just run
            Parallel.Invoke(() => DoSomeWork(), () => DoSomeOtherWork());
            RunExample();

        }

        private static void DoSomeOtherWork()
        {
            Console.WriteLine("Doing other work in parallel");
        }

        private static void DoSomeWork()
        {
            Console.WriteLine("Doing work in parallel");
        }
    }
}

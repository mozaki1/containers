﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskGeneral
{
    public class CustomData
    {
        public int Name { get; set; }
        public long CreationTime { get; set; }
        public int ThreadNum { get; set; }
         
    }
}

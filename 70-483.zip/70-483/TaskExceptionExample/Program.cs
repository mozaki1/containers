﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskExceptionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            RunExample();
        }

        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    ExecuteFlattenExceptionFromAttachedChildTask();
                    break;

                case "2":
                    ExecuteFlattenExceptionFromDetachedChildTask();
                    break;


                default:
                    Environment.Exit(0);
                    break;
            }
        }
        
        private static void ExecuteFlattenExceptionFromDetachedChildTask()
        {
            var task1 = Task.Factory.StartNew(() =>
            {

                var nested1 = Task.Factory.StartNew(() =>
                {
                    throw new ArgumentException("Nested task faulted.");
                });

                // Here the exception will be escalated back to joining thread. 
                // We could use try/catch here to prevent that.
                nested1.Wait();

            });

            try
            {
                task1.Wait();
            }
            catch (AggregateException ae)
            {

                foreach (var e in ae.Flatten().InnerExceptions)
                {
                    if (e is ArgumentException)
                    {
                        // Recover from the exception. Here we just 
                        // print the message for demonstration purposes.
                        Console.WriteLine(e.Message);
                    }
                }
            }
            finally
            {
                RunExample();
            }

        }

        private static void ExecuteFlattenExceptionFromAttachedChildTask()
        {
            var task1 = Task.Factory.StartNew(() =>
            {
                var child1 = Task.Factory.StartNew(() =>
                {
                    var child2 = Task.Factory.StartNew(() =>
                    {
                        throw new ArgumentException("Attached child2 faulted.");
                    },
                    TaskCreationOptions.AttachedToParent);

                    // Uncomment this line to see the exception rethrown. 
                    // throw new MyCustomException("Attached child1 faulted.");
                },
                    TaskCreationOptions.AttachedToParent);
            });

            try
            {
                task1.Wait();
            }
            catch (AggregateException ae)
            {

                foreach (var e in ae.Flatten().InnerExceptions)
                {
                    if (e is ArgumentException)
                    {
                        // Recover from the exception. Here we just 
                        // print the message for demonstration purposes.
                        Console.WriteLine(e.Message);
                    }
                    else
                    {
                        throw;
                    }
                }
                
                // or ... 
                // ae.Flatten().Handle((ex) => ex is MyCustomException);

            }
            finally
            {
                RunExample();
            }

        }
    }
}

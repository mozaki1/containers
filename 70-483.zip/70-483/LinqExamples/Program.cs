﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExamples
{
    class Program
    {
        
        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            System.Threading.Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    LinqWhere();
                    break;
                case "2":
                    LinqSelect();
                    break;
                case "3":
                    LinqTransformSelect();
                    break;
                case "4":
                    LinqSelectMany();
                    break;
                case "5":
                    LinqGroupBy();
                    break;
                case "6":
                    LinqTake();
                    break;
                case "7":
                    LinqSkip();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }
        #region Skip
        private static void LinqSkip()
        {
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var allButFirst4Numbers = numbers.Skip(4);
            
            Console.WriteLine("All but first 4 numbers:");

            foreach (var n in allButFirst4Numbers)
            {
                Console.WriteLine(n);
            }
            RunExample();
        }
        #endregion

        #region Take
        private static void LinqTake()
        {
            Console.WriteLine("Method syntax");
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            var first3Numbers = numbers.Take(3);

            Console.WriteLine("First 3 numbers:");

            foreach (var n in first3Numbers)
            {
                Console.WriteLine(n);
            }
            RunExample();

        }
        #endregion

        #region GroupBy 
        private static void LinqGroupBy()
        {
            Console.WriteLine("Query syntax");
            int[] numbers = { 5, 4, 5, 3, 9, 5, 6, 2, 2, 0 };

            var numberGroups =
                from n in numbers
                group n by n into g
                select new { Remainder = g.Key, Numbers = g };

            foreach (var g in numberGroups)
            {
                Console.WriteLine("Numbers with a remainder of {0} when divided by 5:", g.Remainder);
                foreach (var n in g.Numbers)
                {
                    Console.WriteLine(n);
                }
            }
            Console.WriteLine("Method syntax");
            var groups = numbers.GroupBy(n => n)
                .Where(g => g.Count() > 1)
                .Select(s => new 
                {
                    Index = s.Key, Counts = s.Count()
                }

                )
                .OrderByDescending(d=>d.Counts)
                .ToList();
           

            RunExample();

        }

        #endregion





        #region Select
        private static void LinqSelectMany()
        {
            Console.WriteLine("Query syntax");
            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            int[] numbersB = { 0, 2, 4, 5, 6, 8, 9 ,10};

            var pairs =
                (from a in numbersA
                from b in numbersB
                where a != b && b !=a
                select new { a, b }).ToList();

            Console.WriteLine("Pairs where a < b:");
            foreach (var pair in pairs)
            {
                Console.WriteLine("{0} is less than {1}", pair.a, pair.b);
            }

            Console.WriteLine("Method Syntax");
            //First create an anonymous type ou of the combined 2 sources, then apply the where and kick out the new type
            var pairs2 = numbersA.SelectMany(i => numbersB, (a, b) => new { a = a, b = b })
                .Where(anon => anon.a != anon.b)
                .Select(item => new { item.a, item.b });
            foreach (var pair1 in pairs2)
            {
                Console.WriteLine("{0} is less than {1}", pair1.a, pair1.b);
            }
            RunExample();
        }
        private static void LinqTransformSelect()
        {
            Console.WriteLine("Query syntax");
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            string[] strings = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            var textNums =
                from n in numbers
                select strings[n];

            Console.WriteLine("Number strings:");
            foreach (var s in textNums)
            {
                Console.WriteLine(s);
            }

            Console.WriteLine("Method Syntax");
            IEnumerable<string> transList = numbers.Select(n => strings[n]);
            foreach (var a in transList)
            {
                Console.WriteLine(a);
            }

            Console.WriteLine("Using Anonymous Types");
            string[] words = { "aPPLE", "BlUeBeRrY", "cHeRry" };

            var upperLowerWords =
                from w in words
                select new { Upper = w.ToUpper(), Lower = w.ToLower() };

            foreach (var ul in upperLowerWords)
            {
                Console.WriteLine("Uppercase: {0}, Lowercase: {1}", ul.Upper, ul.Lower);
            } 

             Console.WriteLine("Method Syntax");
             var anonList = words.Select(item => new { Upper = item.ToUpper(), Lower = item.ToLower()});
             foreach (var l in anonList)
             {
                 Console.WriteLine("Uppercase: {0}, Lowercase: {1}", l.Upper, l.Lower);
             }

            RunExample();
        }

        //Select is projection..
        private static void LinqSelect()
        {
            Console.WriteLine("Query syntax");
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            var numsPlusOne =
                from n in numbers
                select n + 1;

            Console.WriteLine("Numbers + 1:");
            foreach (var i in numsPlusOne)
            {
                Console.WriteLine(i);
            } 

            //My example
            var numMinusOne =
                from i in numbers
                select i - 1;

            Console.WriteLine("Numbers - 1:");
            foreach (var i in numMinusOne)
            {
                Console.WriteLine(i);
            } 

            //query syntax style
            Console.WriteLine("Method Syntax style");
            IEnumerable<int> numsMinusOne = numbers.Select(x => x - 1);
            numsMinusOne.ToList().ForEach(k => Console.WriteLine(k));
            RunExample();
        }
        #endregion
        #region Where
        private static void LinqWhere()
        {
            Console.WriteLine("Query syntax");
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            var lowNums =
                (from n in numbers
                where n < 7
                select n).ToList();

            Console.WriteLine("Numbers < 7:");
            foreach (var x in lowNums)
            {
                Console.WriteLine(x);
            }

            Console.WriteLine("My Exampe, just to get the feel of writing this");
            var highNumbers =
                from i in numbers 
                where i > 8 
                select i;
            foreach (var item in highNumbers)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Method syntax");
            var methSynHigh = numbers.Where(i => i > 8);
            foreach (var item in methSynHigh)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("On strings");
            string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            //func returning a list
            var shortDigits = digits.Where((digit, index) => digit.Length < index);
         
            Console.WriteLine("Short digits:");
            foreach (var d in shortDigits)
            {
                Console.WriteLine("The word {0} is shorter than its value.", d);
            } 

            RunExample();
        }
        #endregion

    }
}

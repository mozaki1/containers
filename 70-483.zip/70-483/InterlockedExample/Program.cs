﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace InterlockedExample
{
    
    class MyInterlockedExchangeExampleClass
    {
        //0 for false, 1 for true. 
        private static int usingResource = 0;
        private const int numThreadIterations = 5;
        private const int numThreads = 10;

        static void Main()
        {
            Thread myThread;
            Random rnd = new Random();

            //Spin up some threads
            for(int i = 0; i < numThreads; i++)
            {
                myThread = new Thread(new ThreadStart(MyThreadProc));
                myThread.Name = String.Format("Thread{0}", i + 1);

                //Wait a random amount of time before starting next thread.
                Thread.Sleep(rnd.Next(0, 1000));
                myThread.Start();
            }
        }

        //Each thread is going to attempt to use resource 5 times
        private static void MyThreadProc()
        {
            for(int i = 0; i < numThreadIterations; i++)
            {
                UseResource();

                //Wait 1 second before next attempt.
                Thread.Sleep(1000);
            }
        }

        //A simple method that denies reentrancy. 
        static bool UseResource()
        {

            //so check coming in, and set usingResource to 1 (locked) if it's 0 which it would be the first time
            //0 indicates that the method is not in use. 

            //The Exchange method atomically exchanges the values of the specified variables
            if(0 == Interlocked.Exchange(ref usingResource, 1))
            {
                Console.WriteLine("{0} acquired the lock", Thread.CurrentThread.Name);

                //Code to access a resource that is not thread safe would go here. 

                //Simulate some work
                Thread.Sleep(500);

                Console.WriteLine("{0} exiting lock", Thread.CurrentThread.Name);

                //Release the lock, stting the value back to 0 again
                Interlocked.Exchange(ref usingResource, 0);
                return true;
            }
            else
            {
                //the resource was locked , leave
                Console.WriteLine("   {0} was denied the lock", Thread.CurrentThread.Name);
                return false;
            }
        }

    }
}  

    
﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConcurrentDictionaryExample
{
    class CD_Ctor
    {
        // Demonstrates: 
        //      ConcurrentDictionary<TKey, TValue> ctor(concurrencyLevel, initialCapacity) 
        //      ConcurrentDictionary<TKey, TValue>[TKey] 
        static void Main()
        {
            // We know how many items we want to insert into the ConcurrentDictionary. 
            // So set the initial capacity to some prime number above that, to ensure that 
            // the ConcurrentDictionary does not need to be resized while initializing it. 
            int NUMITEMS = 64;
            int initialCapacity = 101;

            // The higher the concurrencyLevel, the higher the theoretical number of operations 
            // that could be performed concurrently on the ConcurrentDictionary.  However, global 
            // operations like resizing the dictionary take longer as the concurrencyLevel rises.  
            // For the purposes of this example, we'll compromise at numCores * 2. 
            int numProcs = Environment.ProcessorCount;
            int concurrencyLevel = numProcs * 2;

            // Construct the dictionary with the desired concurrencyLevel and initialCapacity
            ConcurrentDictionary<int, int> cd = new ConcurrentDictionary<int, int>(concurrencyLevel, initialCapacity);

            // Initialize the dictionary 
            for (int i = 0; i < NUMITEMS; i++) 
                cd[i] = i * i;

            Task t1 = new Task(() =>
            {
                int val;
                cd.TryRemove(62, out val);
                cd.TryRemove(23, out val);
                cd.TryRemove(42, out val);
                cd.TryUpdate(41, 100000000,1681);
                Console.WriteLine("Removed some values");
            });           
            Task t3 = new Task(() =>
                {
                    foreach (KeyValuePair<int, int> item in cd)
                    {
                        Console.WriteLine("Key: {0}, value {1}", item.Key, item.Value);
                    }
                });
            Console.WriteLine( "starting");
            t1.Start();
        
            t3.Start();
            Console.WriteLine("Waiting");
            Task.WaitAll(t1, t3);
            //will throw because we removed it safely
            try
            {
                Console.WriteLine("Value for 41 should be replaced: {0}", cd[41]);
                Console.WriteLine("The square of 23 is {0} (should be {1})", cd[23], 23 * 23);            
            }
            catch (Exception)
            {

                Console.WriteLine("Should fail because it's gone");
            }
            
             Console.ReadLine();
        }
    }

}

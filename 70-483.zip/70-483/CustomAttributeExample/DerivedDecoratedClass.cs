﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeExample
{
    public class DerivedDecoratedClass : DecoratedClass
    {
        public override void WriteLine()
        {
            // MyMethod will have AuthorAttribute but not SealedAttribute. 
            Console.WriteLine("Im the derived");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeExample
{
    [AuthorAttribute ("Chris Restall", version=1.1)]
    [AuthorAttribute("Someone else", version = 1.2)]
    [Sealed("I wont be applied on classes that inherit from the this class")]
    public class DecoratedClass
    {
        public virtual void WriteLine()
        {
            Console.WriteLine("Im the base");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeExample
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct, AllowMultiple=true)]
    class AuthorAttribute : Attribute
    {
        private string name;
        public double version;
        public DateTime addDate;
        public AuthorAttribute(string name)
        {
            this.name = name;
            this.version = 1.0;
            this.addDate = System.DateTime.Now;
        }
        public string GetName()
        {
            return name;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeExample
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintAuthorInfo(typeof(FirstClass));
            PrintAuthorInfo(typeof(SecondClass));
            PrintAuthorInfo(typeof(ThirdClass));

            Console.ReadLine();
        }
        private static void PrintAuthorInfo(System.Type t)
        {
            System.Console.WriteLine("Author information for {0}", t);

            Console.WriteLine("Is the AuthorAttribute defined for {0}: {1}", t, Attribute.IsDefined(t, typeof(AuthorAttribute)));

            // Using reflection.
            System.Attribute[] attrs = System.Attribute.GetCustomAttributes(t);  // Reflection. 
           

            // Displaying output. 
            foreach (System.Attribute attr in attrs)
            {
  
                if (attr is AuthorAttribute)
                {
                    AuthorAttribute a = (AuthorAttribute)attr;
                    System.Console.WriteLine("   {0}, version {1:f}", a.GetName(), a.version);
                }
            }
        }

    }

    // Class with the Author attribute.
    [AuthorAttribute("P. Ackerman")]
    public class FirstClass
    {
        // ...
    }

    // Class without the Author attribute. 
    public class SecondClass
    {
        // ...
    }

    // Class with multiple Author attributes.
    [AuthorAttribute("P. Ackerman"), AuthorAttribute("R. Koch", version = 2.0)]
    public class ThirdClass
    {
        // ...
    }

}

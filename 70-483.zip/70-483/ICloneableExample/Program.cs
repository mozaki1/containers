﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICloneableExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Person emilyBronte = new Person() { LastName = "Bronte", FirstName = "Emily", PersonAddress = new Address() { HouseNumber = 3, StreetName = "tEST sTREET"} };


            Person herClone = (Person)emilyBronte.Clone();

            Console.WriteLine("Are they equal {0}", Object.Equals(herClone,emilyBronte));

            herClone.isDeepCopy = true;

            Person another = (Person)herClone.Clone();
            Console.WriteLine("With deep copy, Are they equal {0}",  Object.Equals(herClone,another));

            Console.ReadLine();
        }
    }
    public class Person : ICloneable
    {
        public bool isDeepCopy;
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public Address PersonAddress { get; set; }

        public object Clone()
        {
            Person newPerson;
            if (!isDeepCopy)
            {
                newPerson = (Person)this.MemberwiseClone();
                newPerson.PersonAddress = (Address)this.PersonAddress.Clone();
            }
            else
                //Deep copy
                newPerson = new Person() { LastName = this.LastName, FirstName = this.FirstName, PersonAddress = new Address() { StreetName = this.PersonAddress.StreetName, HouseNumber = this.PersonAddress.HouseNumber } };
             

            return newPerson;
        }
       
    }
    
    public class Address : ICloneable
    {
        public int HouseNumber { get; set; }
        public string StreetName { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }


}

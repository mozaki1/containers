﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingSynchronizationExample
{
    //http://stackoverflow.com/questions/251391/why-is-lockthis-bad
    public class Cell
    {
        int cellContents;         // Cell contents
        bool readerFlag = false;  // State flag
        public int ReadFromCell()
        {
            lock (this)   // Enter synchronization block
            {
                if (!readerFlag)
                {            // Wait until Cell.WriteToCell is done producing, nothing is reading at this point
                    try
                    {
                        // Waits for the Monitor.Pulse in WriteToCell
                        Monitor.Wait(this);
                    }
                    catch (SynchronizationLockException e)
                    {
                        Console.WriteLine(e);
                    }
                    catch (ThreadInterruptedException e)
                    {
                        Console.WriteLine(e);
                    }
                }
                Console.WriteLine("Read: {0}", cellContents);
                readerFlag = false;    // Reset the state flag to say reading is done.
                Monitor.Pulse(this);   // Pulse tells Cell.WriteToCell that Cell.ReadFromCell is done.
            }   // Exit synchronization block
            return cellContents;
        }

        public void WriteToCell(int n)
        {
            lock (this)  // Enter synchronization block
            {
                if (readerFlag) //it's reading so wait until its done, Wait until Cell.ReadFromCell is done consuming.
                {
                    try
                    {
                        Monitor.Wait(this);   // Wait for the Monitor.Pulse in ReadFromCell
                    }
                    catch (SynchronizationLockException e)
                    {
                        Console.WriteLine(e);
                    }
                    catch (ThreadInterruptedException e)
                    {
                        Console.WriteLine(e);
                    }
                }
                //Where the work is actually happening - this happens first, it produces, switches the readflag and pulses which signals the wait in Read that it can stop blocking and go
                cellContents = n;
                Console.WriteLine("Produce: {0}", cellContents);
                readerFlag = true;    // Reset the state flag to say producing
                // is done
                Monitor.Pulse(this);  // Pulse tells Cell.ReadFromCell that - talsk to the wait()  in Reader
                // Cell.WriteToCell is done.
            }   // Exit synchronization block
        }
    }
}

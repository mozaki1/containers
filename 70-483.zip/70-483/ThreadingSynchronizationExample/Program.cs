﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingSynchronizationExample
{
    class Program
    {

        public static void Main(String[] args)
        {
            int result = 0;   // Result initialized to say there is no error
            Cell cell = new Cell();

            CellProd prod = new CellProd(cell, 20);  // Use cell for storage, 
            // produce 20 items
            CellCons cons = new CellCons(cell, 20);  // Use cell for storage, 
                                                     // consume 20 items
            Thread consumer = new Thread(new ThreadStart(cons.ThreadRun));
            Thread producer = new Thread(new ThreadStart(prod.ThreadRun));
         
            // Threads producer and consumer have been created, 
            // but not started at this point.

            try
            {
                consumer.Start();
                producer.Start();
              
                // Join both threads with no timeout
                // Run both until done.

                producer.Join();                   
                consumer.Join();
                // threads producer and consumer have finished at this point.
            }
            catch (ThreadStateException e)
            {
                Console.WriteLine(e);  // Display text of exception
                result = 1;            // Result says there was an error
            }
            catch (ThreadInterruptedException e)
            {
                Console.WriteLine(e);  // This exception means that the thread
                // was interrupted during a Wait
                result = 1;            // Result says there was an error
            }
            // Even though Main returns void, this provides a return code to 
            // the parent process.
            Console.ReadLine();
            Environment.ExitCode = result;
        }
    }

    public class CellProd
    {
        Cell cell;         // Field to hold cell object to be used
        int quantity = 1;  // Field for how many items to produce in cell

        public CellProd(Cell box, int request)
        {
            cell = box;          // Pass in what cell object to be used
            quantity = request;  // Pass in how many items to produce in cell
        }
        public void ThreadRun()
        {
            for (int looper = 1; looper <= quantity; looper++)
                cell.WriteToCell(looper);  // "producing"
        }
    }

    public class CellCons
    {
        Cell cell;         // Field to hold cell object to be used
        int quantity = 1;  // Field for how many items to consume from cell

        public CellCons(Cell box, int request)
        {
            cell = box;          // Pass in what cell object to be used
            quantity = request;  // Pass in how many items to consume from cell
        }
        public void ThreadRun()
        {
            int valReturned;
            for (int looper = 1; looper <= quantity; looper++)
                // Consume the result by placing it in valReturned.
                valReturned = cell.ReadFromCell();
        }
    }
}





    


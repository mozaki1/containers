﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace CastConvertExamples
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Defaulting value types");

            int newinteger = new int();  //gives it a default of 0
            int j; //can't just use because new j has no inial value, design error on spin up

            decimal newdecimal = new decimal();
            decimal d;

            Console.WriteLine("the difference between new int {0} and int unassigned is unassigned can't be used at design time", newinteger);
            Console.WriteLine("the difference between new decimal {0} and decimal unassigned is unassigned can't be used at design time", newdecimal);

            Console.WriteLine("______________________________________________________________________");

            Console.WriteLine("Implicit vs explicit casts in widening and narrowing scenarios");
            int myInt = 10000;
            long myLong = myInt;
            Console.WriteLine("Implicitly casted: Widening conversion of shoving an int into a long, no cast needed");
            Console.WriteLine("______________________________________________________________________");


            myLong = 9223372036854775807;  //max long
            myInt = (int)myLong;
            Console.WriteLine ("Explicit cast required: Narrowing conversion of shoving a max long into an int, should quietly overflow: {0}", myInt);
            Console.WriteLine("______________________________________________________________________");

            decimal MyDecimal = 3.1m;
            myInt = (int)MyDecimal;
            Console.WriteLine("Explicit cast required: Narrowing conversion of shoving a decimal into an int, should truncate the precision: {0}", myInt);
            Console.WriteLine("______________________________________________________________________");

            Console.WriteLine("Im a double {0}, Im a float{1}", (double)4.4, (float)4.4f);
            Console.WriteLine("______________________________________________________________________");

            Console.WriteLine("No checked on an overflow");
            int ten = 10;
            int overMaxInt = 2147483647 + ten;
            Console.WriteLine("wrong {0}", overMaxInt);

            Console.WriteLine("Checked on overflow");
            try
            {
                Console.WriteLine(checked(2147483647 + ten));

            }
            catch (OverflowException oe)
            {

                Console.WriteLine("It threw, I caught, carry on");
            }
                      

            Console.WriteLine("______________________________________________________________________");

            Console.WriteLine("Conversion: Parse examples");
            bool b = bool.Parse("true");
            Console.WriteLine("Boolean parse worked because string can convert");
            try
            {
                b = bool.Parse("TRUEs");
            }
            catch (FormatException)
            {
                
                 Console.WriteLine("Boolean parse DID NOT work because string cant convert, throws a format exception");
            }
            
          
            Console.WriteLine("______________________________________________________________________");
            Console.WriteLine("Conversion: TryParse examples");
            Console.WriteLine("Conversion: Parse examples");
            string t = "true";
            bool value;
            if(bool.TryParse(t, out value))
            {
                Console.WriteLine("Boolean Try parse worked because string can convert {0}", value);
            }
            
            if (bool.TryParse("erwer", out value) == false)
            {
                Console.WriteLine("Boolean Try parse failed because string cant convert");
            }
           
            Console.WriteLine("______________________________________________________________________");
            Console.WriteLine("Conversion: Convert Examples");
            try
            {
                bool s = Convert.ToBoolean("a");
            }
            catch (FormatException)
            {

                Console.WriteLine("Format exception because converting 'a' to boolean wont work");
            }
            bool a = Convert.ToBoolean("true");
            Console.WriteLine("Boolean convert works here because true will convert");
          

            Console.WriteLine("______________________________________________________________________");
            Console.WriteLine("Formatting examples:");
            Console.WriteLine("Dates:");
            DateTime dt = DateTime.Now;
            Console.WriteLine("Using the short date specifier 'd' {0}", dt.ToString("d"));
            Console.WriteLine("Using the long date specifier 'D' {0}", dt.ToString("D"));
            Console.WriteLine("Using the Full date/short time specifier 'f' {0}", dt.ToString("f"));
            Console.WriteLine("Using the Full date/Long time specifier 'F' specifier 'd' {0}", dt.ToString("F"));
            Console.WriteLine("Using the General (short) date/short time specifier 'g' {0}", dt.ToString("g"));
            Console.WriteLine("Using the General (short) date/long time specifier 'G' {0}", dt.ToString("G"));
            Console.WriteLine("Using the Short time specifier 't' {0}", dt.ToString("t"));
            Console.WriteLine("Using the Long time specifier 'T' {0}", dt.ToString("T"));
            Console.WriteLine("Using the month year time specifier 'M' {0}", dt.ToString("m"));
            Console.WriteLine("Using the year month specifier 'Y' {0}", dt.ToString("Y"));

            Console.WriteLine("______________________________________________________________________");
            Console.WriteLine("Same Formatting examples with Pakistani Culture:");
            CultureInfo ci = new CultureInfo("ur-PK");
            byte[] bytes;

            Console.WriteLine("Using the short date specifier 'd' {0}", dt.ToString("d", ci));
            Console.WriteLine("Using the long date specifier 'D' {0}", dt.ToString("D", ci));
            Console.WriteLine("Using the Full date/short time specifier 'f' {0}", dt.ToString("f", ci));
            Console.WriteLine("Using the Full date/Long time specifier 'F' specifier 'd' {0}", dt.ToString("F", ci));
            Console.WriteLine("Using the General (short) date/short time specifier 'g' {0}", dt.ToString("g", ci));
            Console.WriteLine("Using the General (short) date/long time specifier 'G' {0}", dt.ToString("G", ci));
            Console.WriteLine("Using the Short time specifier 't' {0}", dt.ToString("t", ci));
            Console.WriteLine("Using the Long time specifier 'T' {0}", dt.ToString("T", ci));
            Console.WriteLine("Using the month year time specifier 'M' {0}", dt.ToString("m", ci));
            Console.WriteLine("Using the year month specifier 'Y' {0}", dt.ToString("Y", ci));
          
            Console.WriteLine("______________________________________________________________________");
            Console.WriteLine("Same Formatting examples with US Culture:");
            CultureInfo culture = new CultureInfo("en-US");
            double someDec = 123.233;

            Console.WriteLine("Money {0}", someDec.ToString("C", culture));
            Console.WriteLine("Money 1 decimal {0}", someDec.ToString("C1", culture));
            Console.WriteLine(1234.ToString("D6"));
            Console.WriteLine(1.ToString("P"));
            Console.WriteLine(100.ToString("P"));
            Console.ReadLine();
           
        }
    }
}

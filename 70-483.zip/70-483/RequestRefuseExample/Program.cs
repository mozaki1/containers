﻿//The request is placed at the assembly level. 
using System.Security.Permissions;

//explicitly refusing FILEIO -  WILL FAIL WITH OUTSIDE CALLS, TRY RUNNING FROMSANDBOX
[assembly: FileIOPermission(SecurityAction.RequestRefuse, Unrestricted = true)]
namespace MyNameSpace
{
    using System;
    using System.Security;
    using System.Security.Permissions;
    using System.IO;

    public class MyClass
    {
        public MyClass()
        {
        }

        public static int Main(string[] args)
        {
            //Creation of the log is attempted in the try block.
            try
            {
                StreamWriter TextStream = new StreamWriter("Log.txt");
                TextStream.WriteLine("This Log was created on {0}", DateTime.Now);
                TextStream.Close();
                Console.WriteLine("The Log was created");
            }
            //Catch the Security exception and inform the user that the 
            //application was not granted FileIOPermission.
            catch (SecurityException)
            {
                Console.WriteLine("This application does not have permission to write to the disk.");
            }

            Console.ReadLine();
            return 0;
        }
    }
}

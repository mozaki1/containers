﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFormatProviderExample
{
    public enum DaysOfWeek { Monday = 1, Tuesday = 2 };
    class Program
    {
        


        static void Main(string[] args)
        {

            //DateTimeFormatInfo:
            DateTime dateValue = new DateTime(2009, 6, 1, 4, 37, 0);
            CultureInfo[] cultures = { new CultureInfo("en-US"), 
                                 new CultureInfo("fr-FR"),
                                 new CultureInfo("it-IT"),
                                 new CultureInfo("de-DE") };
            foreach (CultureInfo culture in cultures)
                Console.WriteLine("{0}: {1}", culture.Name, dateValue.ToString(culture));



            Console.WriteLine("More on formatting");

            long acctNumber;
            double balance;
            DaysOfWeek wday;
            string output;

            acctNumber = 104254567890;
            balance = 16.34;
            wday = DaysOfWeek.Monday;

            output = String.Format(new AcctNumberFormat(),
                                   "On {2}, the balance of account {0:H} was {1:C2}.",
                                   acctNumber, balance, wday);
            Console.WriteLine(output);

            wday = DaysOfWeek.Tuesday;
            output = String.Format(new AcctNumberFormat(),
                                   "On {2}, the balance of account {0:I} was {1:C2}.",
                                   acctNumber, balance, wday);
            Console.WriteLine(output);

            Console.ReadLine();




        }
    }
}

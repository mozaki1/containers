﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;

namespace SerializableExceptionExample
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine(
                "This example of the Exception constructor and Exception.GetObjectData with SerializationInfo and StreamingContext parameters generates the following output.\n");

          

            try
            {
                // This code forces a division by 0 and catches the  resulting exception. 
                try
                {
                    int zero = 0;
                    int ecks = 1 / zero;
                }
                catch (Exception ex)
                {
                    // Create a new exception to throw again, SETTING THE ORIGINAL EXCEPTION AS THE INNEReXCEPTION ON NEW
                    SecondLevelException newExcept = new SecondLevelException("Forced a division by 0 and threw another exception.", ex);

                    Console.WriteLine("Forced a division by 0, caught the Resulting exception, \n and created a derived exception:\n");
                    Console.WriteLine("HelpLink: {0}", newExcept.HelpLink);
                    Console.WriteLine("Source:   {0}", newExcept.Source);

                    // This FileStream is used for the serialization.
                    FileStream stream = new FileStream("NewException.dat", FileMode.Create);

                    try
                    {
                        // Serialize the derived exception.
                        SoapFormatter formatter = new SoapFormatter(null, new StreamingContext(StreamingContextStates.File));
                        formatter.Serialize(stream, newExcept);

                        // Rewind the stream and deserialize the  
                        // exception.
                        stream.Position = 0;
                        SecondLevelException deserExcept =(SecondLevelException)formatter.Deserialize(stream);

                        Console.WriteLine("\nSerialized the exception, and then deserialized the resulting stream into a \nnew exception. The deserialization changed the case of certain properties:\n");

                        // Throw the deserialized exception again. 
                        throw deserExcept;
                    }
                    catch (SerializationException se)
                    {
                        Console.WriteLine("Failed to serialize: {0}",
                            se.ToString());
                    }
                    finally
                    {
                        stream.Close();
                        Console.ReadLine();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("HelpLink: {0}", ex.HelpLink);
                Console.WriteLine("Source:   {0}", ex.Source);

                Console.WriteLine();
                Console.WriteLine(ex.ToString());
            }
        }

    }
}

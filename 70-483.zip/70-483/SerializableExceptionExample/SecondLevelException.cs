﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Security.Permissions;

namespace SerializableExceptionExample
{
    [Serializable()]
    class SecondLevelException : Exception, ISerializable
    {
        // This public constructor is used by class instantiators. 
        public SecondLevelException(string message, Exception inner) : base(message, inner)
        {
            HelpLink = "http://MSDN.Microsoft.com";
            Source = "Exception_Class_Samples";
        }

        // This protected constructor is used for deserialization. 
        protected SecondLevelException(SerializationInfo info,  StreamingContext context) : base(info, context)
        { }

        // GetObjectData performs a custom serialization.
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            // Change the case of two properties, and then use the  
            // method of the base class.
            HelpLink = HelpLink.ToLower();
            Source = Source.ToUpper();

            base.GetObjectData(info, context);
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConcurrentStackExample
{
    class CS_Singles
    {
        // Demonstrates: 
        //      ConcurrentStack<T>.Push(); 
        //      ConcurrentStack<T>.TryPeek(); 
        //      ConcurrentStack<T>.TryPop(); 
        //      ConcurrentStack<T>.Clear(); 
        //      ConcurrentStack<T>.IsEmpty; 
        static void Main()
        {
            int errorCount = 0;

            // Construct a ConcurrentStack
            ConcurrentStack<int> cs = new ConcurrentStack<int>();

            // Push some elements onto the stack
            cs.Push(1);
            cs.Push(2);

            int result;

            // Peek at the top of the stack 
            if (!cs.TryPeek(out result))
            {
                Console.WriteLine("CS: TryPeek() failed when it should have succeeded");
                errorCount++;
            }
            else if (result != 2)
            {
                Console.WriteLine("CS: TryPeek() saw {0} instead of 2", result);
                errorCount++;
            }
            else
            {
                Console.WriteLine("Its 2 as it should be");
            }

            // Pop a number off of the stack 
            if (!cs.TryPop(out result))
            {
                Console.WriteLine("CS: TryPop() failed when it should have succeeded");
                errorCount++;
            }
            else if (result != 2)
            {
                Console.WriteLine("CS: TryPop() saw {0} instead of 2", result);
                errorCount++;
            }
            else
            {
                Console.WriteLine("popped 2 as it should be");
            }

            // Clear the stack, and verify that it is empty
            cs.Clear();
            if (!cs.IsEmpty)
            {
                Console.WriteLine("CS: IsEmpty not true after Clear()");
                errorCount++;
            }
            else
            {
                Console.WriteLine("We cleared it, it's empty");
            }

            if (errorCount == 0) Console.WriteLine("  OK!");
            Console.ReadLine();
        }
    }

}

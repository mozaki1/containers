﻿#define DEBUG
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conditionals
{
    class Program
    {
        //If you run htis in release, none of the "Trace" statements will run because of the conditional "debug"
        static void Main(string[] args)
        {
            Trace.Message("Main Starting");
            #warning Hi there using warning directive
//#error oh no - if uncommented, you can't compile
            if (args.Length == 0)
            {
                Console.WriteLine("No arguments have been passed");
            }
            else
            {
                for (int i = 0; i < args.Length; i++)
                {
                    Console.WriteLine("Arg[{0}] is [{1}]", i, args[i]);
                }
            }

            Console.WriteLine("Line stuff");
            Console.WriteLine("Normal line #1."); // Set break point here.
#line hidden
            Console.WriteLine("Hidden line.");
#line default
            Console.WriteLine("Normal line #2.");

            try 
            {
                #line 200 "Special"
                Console.WriteLine("Would report being on line 200, and file name is now special until the next default is set");
                throw new Exception("illustrate line numbering issue");
            }
            catch(Exception ex) 
            {
                Console.WriteLine("Thinks we are on line 200+ and has renamed the file {0}, {1}",ex.Message, ex.StackTrace);
            }
            //put numbers back
            #line default
            Trace.Message("Main Ending");
            Console.ReadLine();
        }

    }
}


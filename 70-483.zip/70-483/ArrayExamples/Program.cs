﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayExamples
{
    class Program
    {
        static void Main(string[] args)
        {

            // Declare a single-dimensional array  
            int[] array1 = new int[5];

            // Declare and set array element values 
            int[] array2 = new int[] { 1, 3, 5, 7, 9 };
            Console.WriteLine("Expecting 5: {0}", array2[2]);

            // Alternative syntax 
            int[] array3 = { 1, 2, 3, 4, 5, 6 };

            // Declare a two dimensional array - ala I have 2 entries, each has 3 item in it
            int[,] multiDimensionalArray1 = new int[2, 3];
            Console.WriteLine("not populated: GetUpperBound (0 based count and index): Multi dimensionsional array with {0} row entries each withj a limit of {1} entries", multiDimensionalArray1.GetUpperBound(0), multiDimensionalArray1.GetUpperBound(1));
            Console.WriteLine("not populated: Multi dimensional Array total Length (1st dimension x 2nd dimension): {0} expected {1}", multiDimensionalArray1.Length, 2*3);
            Console.WriteLine("not populated: GetLength (0 based index but count is not 0 based) Multi dimensional Array dimensional row Length: {0}, column Length {1}", multiDimensionalArray1.GetLength(0), multiDimensionalArray1.GetLength(1));
            // Declare and set array element values 
            int[,] multiDimensionalArray2 = { { 1, 2, 3 }, { 4, 5, 6 } };
            
            Console.WriteLine("Expecting: 5: {0}", multiDimensionalArray2[1,1]);

            // Declare a jagged array - The following is a declaration of a single-dimensional array that has three elements, each of which is a single-dimensional array of integers:
            int[][] jaggedArray = new int[3][];

            jaggedArray[0] = new int[5]; //Element 0 of the array, the first array of the 3 has, 5 integers in it
            jaggedArray[1] = new int[4];  //Element 1 of the array, the econd array of the 3 has, 4 integers in it
            jaggedArray[2] = new int[2]; //Element 2 of the array, the third array of the 3 has, 2 integers in it

            // Set the values of the first array in the jagged array structure
            jaggedArray[0] = new int[5] { 1, 2, 3, 4, 5 };
            jaggedArray[1] = new int[4] { 8, 9, 10, 45 };
            jaggedArray[2] = new int[2] {85,23};
            Console.WriteLine("Grabbing the 1st array and the 3rd entery should be 3: {0}", jaggedArray[0][2]);
            Console.WriteLine("Grabbing the 2st array and the 4th entery should be 10: {0}", jaggedArray[1][2]);
            Console.WriteLine("Jagged Array GetUpperBound on the array itself, should be 2  since (3 entries - 1)-  {0}", jaggedArray.GetUpperBound(0));
            Console.WriteLine("Jagged Array GetUpperBound on each entry, (0 based index and count) expecting 4:{0}, 3:{1}, 1:{2}", jaggedArray[0].GetUpperBound(0), jaggedArray[1].GetUpperBound(0), jaggedArray[2].GetUpperBound(0));
            Console.WriteLine("Jagged Array Total Length, should be 3 since there's only 1 dimension (3*1): {0}", jaggedArray.Length);
            Console.WriteLine("Jagged Array dimensions lengths, expecting 5:{0},  4:{1}, 2:{2}", jaggedArray[0].GetLength(0), jaggedArray[1].GetLength(0), jaggedArray[2].GetLength(0));

            BuildAJaggedArray();
            Console.ReadLine();
        }

        private static void BuildAJaggedArray()
        {
            // Declare the array of two elements: 
            int[][] arr = new int[2][];

            // Initialize the elements:
            arr[0] = new int[10] { 1, 3, 5, 7, 9, 45, 23, 11, 56, 78 };
            arr[1] = new int[4] { 2, 4, 6, 8 };

            // Display the array elements: arr.Length = 2 (2 entries (int arrays) * 1 dimension)
            for (int i = 0; i < arr.Length; i++)
            {
                System.Console.Write("Element (array #({0}): ", i);
                
                //aar[i] -  now we are iterating the array stored in entry i
                for (int j = 0; j < arr[i].Length; j++)
                {
                    System.Console.WriteLine("in array#{2}, rifling through: value={0}  {1}", arr[i][j], j == (arr[i].Length - 1) ? "" : " ", i);
                }
                System.Console.WriteLine();
            }
          


        }
    }
}

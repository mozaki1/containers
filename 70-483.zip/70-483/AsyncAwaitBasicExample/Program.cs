﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AsyncAwaitBasicExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("In main, callinginto first asyn method");
            StartTheAsyncChainAsync();
            Console.WriteLine("In main, Blocked, this won't print until the previous method is done");

            Console.ReadLine();
            
        }

        private static async void StartTheAsyncChainAsync()
        {
            Console.WriteLine("Parent: Started");
            Task<int> returnedTaskTResult = TaskOfTResult_MethodAsync();
            Console.WriteLine("Parent: First Method started up and ran to it's await, it yielded back to me");
            Console.WriteLine("Parent:Doing other things as top parent caller");
            //Thread.Sleep(4000);
            Console.WriteLine("Parent: Done doing other things, checking on async results, thios would actually Yield back to Main if it was awaiting");
            int intResult = await returnedTaskTResult;

           Console.WriteLine("Parent:Results {0}", intResult);


        }

        // Signature specifies Task<TResult>
        private static async Task<int> TaskOfTResult_MethodAsync()
        {
            int hours;
          //  Console.WriteLine("First method: calls to the long task");
            Task<int> hoursTask = DoSomeWork();
         //   Console.WriteLine("First method: doing other work");
            //Thread.Sleep(6000);
            Console.WriteLine("First method: Done doing other, now blocked on the await of Long Task, yield back to Caller (Parent)");
            hours = await hoursTask;
         //   Console.WriteLine("First method: Got it,{0}",hours );
            return hours;
        }

        private static async Task<int> DoSomeWork()
        {
           // Console.WriteLine("Long Task: starting, with an await, yield back to Caller (First Method)");
            await Task.Delay(100);
          //  Console.WriteLine("Long Task: finishing");
            return  10;
        }


       

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace TraceListenerExample
{
    class Program
    {
        private static TraceSource mySource = new TraceSource("TraceSourceApp");
        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            System.Threading.Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    ConsoleTraceListener();
                    break;
                case "2":
                    SwitchExample();
                    break;
                case "3":
                    TraceSourceExample();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void TraceSourceExample()
        {
            Activity1();

            // Change the event type for which tracing occurs.
            // The console trace listener must be specified 
            // in the configuration file. First, save the original
            // settings from the configuration file.
            EventTypeFilter configFilter = (EventTypeFilter)mySource.Listeners["console"].Filter;

            // Then create a new event type filter that ensures 
            // critical messages will be written.
            mySource.Listeners["console"].Filter = new EventTypeFilter(SourceLevels.Critical);
            Activity2();

            // Allow the trace source to send messages to listeners 
            // for all event types. This statement will override 
            // any settings in the configuration file.
            mySource.Switch.Level = SourceLevels.All;

            // Restore the original filter settings.
            mySource.Listeners["console"].Filter = configFilter;
            Activity3();
            mySource.Close();

            RunExample();
        }

        private static void Activity1()
        {
            mySource.TraceEvent(TraceEventType.Error, 1,"Error message.");
            mySource.TraceEvent(TraceEventType.Warning, 2,"Warning message.");
        }
        private static void Activity2()
        {
            mySource.TraceEvent(TraceEventType.Critical, 3, "Critical message.");
            mySource.TraceInformation("Informational message.");
        }
        private static void Activity3()
        {
            mySource.TraceEvent(TraceEventType.Error, 4,"Error message.");
            mySource.TraceInformation("Informational message.");
        }

        private static void SwitchExample()
        {
            TextWriterTraceListener aListerner = new TextWriterTraceListener(Console.Out);
            //.tHIS SWITCH WILL BE CONFIGURABLE FROM CONFIG FILE
            TraceSwitch generalSwitch =  new System.Diagnostics.TraceSwitch("General",  "Entire application");
            generalSwitch.Level = TraceLevel.Off;

            if (generalSwitch.Level == TraceLevel.Verbose) aListerner.WriteLine("WON'T WRITE BECAUSE SWITCH SETTING IS OFF");
            generalSwitch.Level = TraceLevel.Verbose;
            Console.WriteLine(generalSwitch.Level);
           if(generalSwitch.Level == TraceLevel.Verbose) aListerner.WriteLine("wRITE AWAY");
            aListerner.Flush();
            RunExample();
        }

        private static void ConsoleTraceListener()
        {            
            // Creates the new trace listener.
            TextWriterTraceListener myListener =  new System.Diagnostics.TextWriterTraceListener(Console.Out);
            
            //Add it to the global collection
            Trace.Listeners.Add(myListener);

            myListener.Write("Writing something out via Trace");
            myListener.WriteLine("Writing something else out via Trace");
            myListener.Flush();
            RunExample();
        }
    }
}

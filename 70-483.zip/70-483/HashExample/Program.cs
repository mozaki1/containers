﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace HashExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Hash of P4ssw0rd!
            var storedPasswordHash = new byte[]
            {
                148,152,235,251,242,51,18,100,176,51,147,249,128,175,164,106,204,48,47,154,75,82,83,170,111,8,107,51,13,83,2,252
            };


            var enteredPassword = Encoding.Unicode.GetBytes("P4ssw0rd!");
            var enteredPasswordHash = SHA256.Create().ComputeHash(enteredPassword);

            if(enteredPasswordHash.SequenceEqual(storedPasswordHash))
                Console.WriteLine("Access accepted!");
            else
                Console.WriteLine("Access Denied");

            //Console.WriteLine("Next Sample......);
            const string testMe = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            byte[] testMeArray = Encoding.Unicode.GetBytes(testMe);

            var nonFipsHash = SHA384Managed.Create().ComputeHash(testMeArray);
            var fipsHash = SHA384Cng.Create().ComputeHash(testMeArray);

            string nonFispString = Encoding.Unicode.GetString(nonFipsHash);
            string fispString = Encoding.Unicode.GetString(fipsHash);

            Console.WriteLine("Non Fips string: {0}", nonFispString);
            Console.WriteLine("Fips string:     {0}", fispString);
            Console.WriteLine(fipsHash.SequenceEqual(nonFipsHash));


           // Console.WriteLine(val);
            Console.ReadLine();
        }
    }
}

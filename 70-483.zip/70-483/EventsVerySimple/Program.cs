﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EventsVerySimple
{
    class Program
    {
        static void Main(string[] args)
        {
            var x = new Animal();

            //Sender and args parameters.. Wired event up to do a console.writeline when triggered via the Speak Method
            x.OnSpeak += (s, e) => Console.WriteLine("On Speak!");
            x.OnSpeak += (s, e) => Console.WriteLine(e.Cancel ? "Cancel" : "Do not cancel");

            Console.WriteLine("Before");
            Console.WriteLine(string.Empty);

            //Trigger event fire
            x.Speak(true);
            x.Speak(false);

            Console.WriteLine(string.Empty);
            Console.WriteLine("After");

            Console.Read();
        }

        public class Animal
        {
            //My basic event - In component model
            public event CancelEventHandler OnSpeak;

            //My public method to raise the event
            public void Speak(bool cancel)
            {
                OnSpeak(this, new CancelEventArgs(cancel));
            }
        }
    }
}

﻿using System;
using System.Security.Permissions;
using System.IO;

//Requests a fileIOpermission from the sandbox which does not grant it, thus a securityexception would be thrown
[assembly: FileIOPermission(SecurityAction.RequestMinimum, Unrestricted = true)]
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Test is loaded.");
            //this should fail because the 
            File.Create("test.txt");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceExample
{
    class Box : IDimensions, IEnglishDimensions
    {
        float lengthInches;
        float widthInches;

        public Box(float length, float width)
        {
            lengthInches = length;
            widthInches = width;
        }
        // Explicit interface member implementation: Users of Box won't be able to use this if they just create a Box object, they'd need ot create an instance of IDimensions
        float IDimensions.Length()
        {
            return lengthInches * 2.54f;
        }
        // Explicit interface member implementation:
        float IDimensions.Width()
        {
            return widthInches * 2.54f;
        }

        // Explicit interface member implementation: Users of Box won't be able to use this if they just create a Box object, they'd need ot create an instance of IDimensions
        float IEnglishDimensions.Length()
        {
            return lengthInches;
        }
        // Explicit interface member implementation:
        float IEnglishDimensions.Width()
        {
            return widthInches;
        }
    }
}

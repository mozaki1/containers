﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceExample
{
    // When a member is explicitly implemented, it cannot be accessed through a class instance, but only through an instance of the interface
    class Program
    {
        static void Main(string[] args)
        {
            // Declare a class instance "myBox":
            Box myBox = new Box(30.0f, 20.0f);


            //LESSON 1: How an implementation of Box won't let you use explicit interface members unless you cast to the Interface
            // Print out the dimensions of the box:
           /* The following commented lines would produce compilation 
            errors because they try to access an explicitly implemented
            interface member from a class instance:                   */
           // System.Console.WriteLine("Length: {0}", myBox.Length());
           // System.Console.WriteLine("Width: {0}", myBox.Width());
            
            // Declare an interface instance "myDimensions":  This will have access to the 2 methods - YOU CANNOPT CALL THE IEnglishDimnsions version
            IDimensions myDimensions = (IDimensions)myBox;
            /* Print out the dimensions of the box by calling the methods From an instance of the interface:                         */
            Console.WriteLine("As an Regular Dimensions Box");
            System.Console.WriteLine("Length: {0}", myDimensions.Length());
            System.Console.WriteLine("Width: {0}", myDimensions.Width());

            IEnglishDimensions englishDimensions = (IEnglishDimensions)myDimensions;
            Console.WriteLine("As an English Dimensions Box");
            /* Print out the dimensions of the box by calling the methods From an instance of the interface:                         */
            System.Console.WriteLine("Length: {0}", englishDimensions.Length());
            System.Console.WriteLine("Width: {0}", englishDimensions.Width());



            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text;
namespace ioExample
{
    class Program
    {
        

        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            System.Threading.Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                   GetDriveInfoSimple();
                    break;
                case "2":
                    GetFileInfoSimple();
                    break;
                case "3":
                    CreateFileSimple();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void CreateFileSimple()
        {
            string filePath = @"C:\Users\crestall\Desktop\test.txt";
            FileStream fs = File.Create(filePath,1024,FileOptions.None);

            //wRITE
            string data = "data to write to the file";
            byte[] dataByte = new UTF8Encoding().GetBytes(data);

            fs.Write(dataByte, 0, dataByte.Length);
            fs.Flush();
            fs.Close();

            //rEAD
            FileStream fsread = File.Open(filePath,FileMode.Open,FileAccess.Read);
            byte[] buffer = new byte[1024];
            UTF8Encoding temp = new UTF8Encoding(true);
            while (fsread.Read(buffer, 0, buffer.Length) > 0)
            {
                Console.WriteLine(temp.GetString(buffer)); 
            }
            fsread.Close();
            File.Delete(filePath);

            RunExample();
        }

        private static void GetFileInfoSimple()
        {
       
            string filePath = @"C:\Users\crestall\Desktop\music.txt";
            FileInfo fi = new FileInfo(filePath);
           Console.WriteLine("File Exist {0}",fi.Exists );
           Console.WriteLine("File Last Access {0}", fi.LastAccessTime);
           Console.WriteLine("File Last Write {0}", fi.LastWriteTime);
           Console.WriteLine("File Attributes {0}", fi.Attributes);
             Console.WriteLine("File Full path {0}", fi.DirectoryName);

             RunExample();
        }



        private static void GetDriveInfoSimple()
        {
            DriveInfo[] di = DriveInfo.GetDrives();
            foreach (var drive in di)
            {
                Console.WriteLine("-------" + drive.Name + "-------");
                Console.WriteLine("Free Space: {0}", drive.AvailableFreeSpace);
                Console.WriteLine("Drive Format: {0}", drive.DriveFormat);
                Console.WriteLine("Drive Type: {0}", drive.DriveType);
                Console.WriteLine("is Ready: {0}", drive.IsReady);
                Console.WriteLine("Root letter: {0}", drive.RootDirectory);
                Console.WriteLine("Total Free space: {0}", drive.TotalFreeSpace);
                Console.WriteLine("Size: {0}", drive.TotalSize);
                Console.WriteLine("Label: {0}", drive.VolumeLabel);
            }
            
            RunExample();
        }
    }
}

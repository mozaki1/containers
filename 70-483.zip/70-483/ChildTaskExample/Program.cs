﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ChildTaskExample
{
    class Program
    {
        static void Main(string[] args)
        {
            RunExample();
        }

        private static void RunExample()
        {
            Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    DetachedChildExample();
                    break;
                case "2":
                    AttachedChildExample();
                    break;
                case "3":
                    DetachedChildExampleParentWaitingOnChild();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void  DetachedChildExample()
        {
            var parent = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Parent executing.");

                var child = Task.Factory.StartNew(() =>
                {
                    Console.WriteLine("Detached Nested task starting, independant of the parent.");
                    Thread.SpinWait(500000);
                    Console.WriteLine("Detached Nested task completing, independant of the parent.");
                }
                );
            });

            parent.Wait();
            Console.WriteLine("Parent has completed.");
            RunExample();
        }

        private static void DetachedChildExampleParentWaitingOnChild()
        {
            var parent = Task<int>.Factory.StartNew(() =>
            {
                Console.WriteLine("Parent executing.");

                var child = Task<int>.Factory.StartNew(() =>
                {
                    Console.WriteLine("Detached Nested task starting, independant of the parent.");
                    Thread.SpinWait(500000);
                    Console.WriteLine("Detached Nested task completing, independant of the parent.");
                    return 100;
                }
                );
                Console.WriteLine("Parent Waiting on child to get Result, simulated attachedToParent Behavior");
                return child.Result;
            });

            parent.Wait();
            Console.WriteLine("Parent has completed.");
            RunExample();
        }





        private static void AttachedChildExample()
        {
            var parent = Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Parent executing.");

                var child = Task.Factory.StartNew(() => 
                {
                    Console.WriteLine("Attached Nested task starting, Dependent of the parent.");
                    Thread.SpinWait(500000);
                    Console.WriteLine("Attached Nested task completing, Dependent of the parent.");
                }, TaskCreationOptions.AttachedToParent);
            }, TaskCreationOptions.DenyChildAttach);
            parent.Wait();
            Console.WriteLine("Parent has completed.");
            RunExample();
        }
               

       

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
namespace SymmetricEncryption
{
    class Program
    {
        static void Main(string[] args)
        {

            string dataToEncrypt = "Hey encrypt me I need to be encrypted badly";
            var dataToProtectArray = Encoding.Unicode.GetBytes(dataToEncrypt);

            //use random 16 element key (16 bytes), larger key = more encrypted - should be secret
            var key = new byte[] 
            {
                12, 2, 56, 117, 12, 67, 33, 23, 12, 2, 56, 117, 12, 67, 33, 23
            };

            //Seed in random of sorts - changes the offset of where encryption starts
            var initializationVector = new byte[]
            {
                37, 99, 102, 23, 12, 22, 156, 204, 11, 12, 23, 44, 55, 1, 157, 233
            };

            byte[] symEncryptedData;

            var algorithm = Aes.Create();

            using(var encryptor = algorithm.CreateEncryptor(key,initializationVector))
            using(var memStream = new MemoryStream())
            using (var cryptoStream = new CryptoStream(memStream, encryptor, CryptoStreamMode.Write))
            {
                cryptoStream.Write(dataToProtectArray, 0, dataToProtectArray.Length);
                cryptoStream.FlushFinalBlock();
                symEncryptedData = memStream.ToArray();
            }

            byte[] symUnencyptedData;
            using (var decryptor = algorithm.CreateDecryptor(key, initializationVector))
            using(var memStream = new MemoryStream())
            using (var cryptoStream = new CryptoStream(memStream,decryptor,CryptoStreamMode.Write))
            {
                cryptoStream.Write(symEncryptedData, 0, symEncryptedData.Length);
                cryptoStream.FlushFinalBlock();
                symUnencyptedData = memStream.ToArray();
            }

            algorithm.Dispose();

            if(dataToProtectArray.SequenceEqual(symUnencyptedData))           
                Console.WriteLine("They Match!");           
            else
                Console.WriteLine("They Dont Match!");

            Console.ReadLine();
        }
    }
}

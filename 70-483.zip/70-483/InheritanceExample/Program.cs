﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceExample
{
    class Program
    {
        static void Main(string[] args)
        {

            var animals = new IAnimal[] { new Monkey(), new Dog() };
            foreach (var animal in animals)
            {
                DisplayAnimalData(animal);
            }
            Console.ReadLine();
        }

        private static void DisplayAnimalData(IAnimal animal)
        {
            Console.WriteLine("Animal has {0} legs and makes this sound", animal.NumberOfLegs);
            animal.Vocalize();
            ISpanishAnimal spanishAnimal = (ISpanishAnimal)animal;

           if(animal == spanishAnimal)
               Console.WriteLine("The same");

            Console.WriteLine("Spanish Animal has {0} legs and makes this sound", spanishAnimal.NumberOfLegs);
            spanishAnimal.Vocalize();
            
        }
    }

    public interface IAnimal
    {
        int NumberOfLegs { get; }
        void Vocalize();
    }
    public interface ISpanishAnimal
    {
        int NumberOfLegs { get; }
        void Vocalize();
    }

    public abstract class baseAnimal : IAnimal, ISpanishAnimal
    {
        int _numberOfLegs;
        private readonly string _sound;
        public baseAnimal(int numberOfLegs, string sound)
        {
            _numberOfLegs = numberOfLegs;
            
            _sound = sound;
        }

        void ISpanishAnimal.Vocalize()
        {
            Console.WriteLine(_sound + "in Spanish");
        }

        int ISpanishAnimal.NumberOfLegs
        {
            get
            {
                return _numberOfLegs * 5;
            }          
        }
        void IAnimal.Vocalize()
        {
            Console.WriteLine(_sound);
        }

        int IAnimal.NumberOfLegs
        {
            get
            {
                return _numberOfLegs;
            }
        }

                
        public string Sound
        {
            get { return _sound; }       
        }
        
    }
    public class Monkey : baseAnimal
    {
        public Monkey() : base(2,"Monkey Sound!") { }
    }
    public class Dog : baseAnimal
    {
        public Dog() : base(4, "Woof!") { }
    }
   
}

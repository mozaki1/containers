﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;

namespace DebugSimpleExamples
{
    class Program
    {        

        static void Main(string[] args)
        {
            RunExample();
        }
        private static void RunExample()
        {
            System.Threading.Thread.SpinWait(1000000);
            Console.WriteLine(Environment.NewLine + Environment.NewLine + "Please enter a run option");
            string option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    SimpleDebug();
                    break;
                default:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void SimpleDebug()
        {
            //Write to the console, could write to anything.
            Debug.Listeners.Add(new TextWriterTraceListener(Console.Out));
            //Tell it to always flush after a writeline
            Debug.AutoFlush = true;


            Debug.Indent();
            Debug.WriteLine("Entering Main");
            Debug.WriteIf(1 == 0, "one does not equal 0 this should not be displayed");
            Debug.WriteLineIf(2 == 2, "two does equal 2 this should be displayed");
            Debug.WriteLineIf(1 == 1, "1 equals 1 this should be displayed - WriteLineIf when TRUE");
            Debug.Assert(1 == 0,"one does not equal 0, DISPLAY WITH STACK - assert shows when condition is FALSE");  //THIS WILL THROW WITH STACK
            Debug.Print("{0} being printed via a print command", Assembly.GetExecutingAssembly().FullName);
            Console.WriteLine("Hello World.");


            Debug.WriteLine("Exiting Main");
            Debug.Unindent();
            RunExample();

        }
    }
}

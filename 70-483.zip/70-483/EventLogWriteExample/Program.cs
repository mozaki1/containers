﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;

namespace EventLogWriteExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create the source, if it does not already exist. 
            if (!EventLog.SourceExists("ChrisSource"))
            {
                //An event log source should not be created and immediately used. 
                //There is a latency time to enable the source, it should be created 
                //prior to executing the application that uses the source. 
                //Execute this sample a second time to use the new source.
                EventLog.CreateEventSource("ChrisSource", "ChrisLog");
                Console.WriteLine("CreatedEventSource");
                Console.WriteLine("Exiting, execute the application a second time to use the source.");
                // The source is created.  Exit the application to allow it to be registered. 
                Console.ReadLine();
            }

            // Create an EventLog instance and assign its source.
            EventLog myLog = new EventLog();
            myLog.Source = "ChrisSource";

            // Write an informational entry to the event log.    
            myLog.WriteEntry("Writing to event log.");


            EventLog[] logs = EventLog.GetEventLogs();
            foreach (EventLog log in logs)
            {

                if (log.LogDisplayName == "ChrisLog")
                {
                    Console.WriteLine("My log was found");
                    EventLogEntryCollection mySourceEntries = log.Entries;
                    foreach (EventLogEntry item in mySourceEntries)
                    {
                        Console.WriteLine("Playback of {0}, from my eventlog source", item.Message);
                    }
                }
                else
                {
                    Console.WriteLine("Log i don't care about {0}", log.LogDisplayName);
                }
            }

            Console.ReadLine();
        }
    }
}

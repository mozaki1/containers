﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Xml;

namespace DataContractSerializerExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Record record1 = new Record(1, 2, "+", 3);
            Console.WriteLine("Original record: {0}", record1.ToString());

            MemoryStream stream1 = new MemoryStream();

            //Serialize the Record object to a memory stream using DataContractSerializer.
            DataContractSerializer serializer = new DataContractSerializer(typeof(Record));
            serializer.WriteObject(stream1, record1);

            //Be kind rewind
            stream1.Position = 0;

            //Deserialize the Record object back into a new record object.
            Record record2 = (Record)serializer.ReadObject(stream1);
            Console.WriteLine("Deserialized record: {0}", record2.ToString());

            MemoryStream stream2 = new MemoryStream();
            XmlDictionaryWriter binaryDictionaryWriter = XmlDictionaryWriter.CreateBinaryWriter(stream2);
            serializer.WriteObject(binaryDictionaryWriter, record1);
            binaryDictionaryWriter.Flush();

            //report the length of the streams
            Console.WriteLine("Text Stream is {0} bytes long", stream1.Length);
            Console.WriteLine("Binary Stream is {0} bytes long", stream2.Length);
            Console.ReadLine();


        }
    }
}

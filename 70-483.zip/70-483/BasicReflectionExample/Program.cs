﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace BasicReflectionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            object assm = Activator.CreateInstance(typeof(Dog));

            Type t = typeof(Dog);

            ConstructorInfo[] constructors = t.GetConstructors();
            PropertyInfo[] props = t.GetProperties();
            MethodInfo[] meths = t.GetMethods();
            object[] attribs = t.GetCustomAttributes(true);
            FieldInfo[] fields = t.GetFields();

            Console.WriteLine("Constructors");
            foreach (ConstructorInfo constructor in constructors)
            {
                Console.WriteLine("Constructor name:{0} module:{1} isPublic:{2} isPrivate:{3} isdefined:{4}",constructor.Name, constructor.Module.Name, constructor.IsPublic, constructor.IsPrivate, constructor.ReflectedType.Name);   
            }
            Console.WriteLine("Propereties");
            foreach (PropertyInfo prop in props)
            {
                Console.WriteLine(prop.Name + " " + prop.GetValue(assm,null));
            }
            props[0].SetValue(assm, 2);
            Console.WriteLine(props[0].GetValue(assm,null));

            Console.WriteLine("Methods");
            foreach (var meth in meths)
            {
                Console.WriteLine(meth.Name);
                Console.WriteLine(meth.IsPublic);
                if (meth.Name == "Bark")
                    Console.WriteLine( meth.Invoke(assm, new object[]{}));
            }

            Console.WriteLine("Fields");
            foreach (FieldInfo field in fields)
            {
                Console.WriteLine("Field name:{0} isPublic:{2} isPrivate:{3}",field.Name, field.IsPrivate, field.IsPublic);
            }
            Console.ReadLine();
        }
    }
    internal class Dog
    {
        public event EventHandler someEvent;
        private int someField = 5;
        public int NumberOfLegs { get; set; }

        public Dog()
        {
            NumberOfLegs = 4;
        }

        public Dog(int legs)
        {
            NumberOfLegs = legs;
        }

        public string Bark()
        {
            return "woof";
        }
    }
}

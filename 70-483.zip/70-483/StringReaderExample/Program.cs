﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
namespace StringReaderExample
{


    class Program
    {
        static int Method1(string data)
        {
            int count = 0;
      
            using (StringReader reader = new StringReader(data))
            {
                while (true)
                {
                    string line = reader.ReadLine();
                    if (line == null)
                    {
                        break;
                    }
                    count += line.Length;
                }
            }
            return count;
        }

        static int Method2(string data)
        {
            int count = 0;
            string[] lines = data.Split(new char[] { '\n' });
            foreach (string line in lines)
            {
                count += line.Length;
            }
            return count;
        }

        static void Main()
        {
            const string data = "Dot\nNet\nPerls\nIs a website\nDo you like it?Dot\nThis\nTest\nis\nstupid";
            Console.WriteLine(Method1(data));
            Console.WriteLine(Method2(data));
            const int max = 10000000;
            var s1 = Stopwatch.StartNew();
            for (int i = 0; i < max; i++)
            {
                Method1(data);
            }
            s1.Stop();
            var s2 = Stopwatch.StartNew();
            for (int i = 0; i < max; i++)
            {
                Method2(data);
            }
            s2.Stop();
            Console.WriteLine("StringReader implementation:");
            Console.WriteLine(((double)(s1.Elapsed.TotalMilliseconds * 1000000) /
                max).ToString("0.00 ns"));
            Console.WriteLine("Split implementation:");
            Console.WriteLine(((double)(s2.Elapsed.TotalMilliseconds * 1000000) /
                max).ToString("0.00 ns"));
            Console.Read();
        }
    }
}


    